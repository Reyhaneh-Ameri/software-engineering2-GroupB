package com.iust.fandogh.entity;

public class Player {
	public static int ID_COUNTER = 0;
	
	int ID;
	String nickname = null;
	
	public Player() {
		this.ID = ID_COUNTER;
		ID_COUNTER++;
	}
	
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getNickname() {
		return nickname;
	}
	
	public int getID() {
		return ID;
	}
}
