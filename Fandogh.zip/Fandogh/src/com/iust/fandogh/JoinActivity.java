package com.iust.fandogh;

import java.util.ArrayList;
import java.util.HashMap;

import com.iust.fandogh.controllers.ClientNetworkController;
import com.iust.fandogh.controllers.GameController;
import com.iust.fandogh.entity.Player;
import com.iust.fandogh.messages.GameMSG;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

/**
 * The class for representing join page and show network events in userinterface
 * @author Farhad hosseinkhani,reyhane ameri
 *
 */
public class JoinActivity extends Activity{
	LinearLayout usersList;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_join);
		usersList = (LinearLayout)findViewById(R.id.UsersList);
		
		new ClientNetworkController(getIntent().getStringExtra(MainActivity.IP), 
				getIntent().getStringExtra(MainActivity.NICKNAME));
		ClientNetworkController.cnc.setActivity(this);
		
		getIntent().removeExtra(MainActivity.NICKNAME);
		getIntent().removeExtra(MainActivity.IP);
	}
	
	public void refreshPlayers(String[] playersName) {
		usersList.removeAllViews();
		for (String name : playersName) {
			TextView nn = new TextView(this);
	    	nn.setText(name);
	    	nn.setTextColor(Color.RED);
	    	nn.setTextSize(20f);
	    	usersList.addView(nn);
		}
	}
	
	public void startGame(GameMSG msg) {
		Log.d(MainActivity.tag, "start the fucking game");
		
		Intent intent = new Intent(this, GameActivity.class);
    	intent.putExtra("modes", msg.getModes());
    	intent.putExtra("rounds", msg.getRounds());
    	intent.putExtra("alphabets", msg.getDashbordAlphabets());
    	intent.putExtra("score", msg.getScore());
		
		startActivity(intent);
		this.finish();
	}
	
	@Override
	public void onBackPressed() {
		ClientNetworkController.cnc.exitGame();
		
		super.onBackPressed();
	}
}
