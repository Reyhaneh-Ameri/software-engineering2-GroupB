package com.iust.fandogh;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.ToggleButton;
import android.widget.TableLayout.LayoutParams;

public class FinalActivity extends Activity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_final);
		
		ArrayList<String> res = (ArrayList<String>)getIntent().getSerializableExtra("final");
		
		TableLayout form = (TableLayout)findViewById(R.id.words);
		for (String name : res) {
			TableRow row = new TableRow(this);
			LinearLayout.LayoutParams rowParams = new LayoutParams(LayoutParams.FILL_PARENT, 0);
			row.setLayoutParams(rowParams);
			
			TableRow.LayoutParams nameParams;
			TextView wordT = new TextView(this);
			wordT.setText(name);
			wordT.setTextSize(30f);
			wordT.setTextColor(Color.RED);
			nameParams = new TableRow.LayoutParams(0, TableRow.LayoutParams.FILL_PARENT, 30f);
			row.addView(wordT, nameParams);
			
			form.addView(row);
		}
	}
}
