package com.iust.fandogh.messages;

import java.io.Serializable;
import java.util.Set;

public class MiniGame01MSG implements Serializable {
	public final static int GAME_INITIALIZE = 1;
	public final static int GAME_FINISHED = 2;
	public final static int GAME_WIN = 3;
	
	int type = 0;
	boolean winAccept = false;
	Set<Pairs> add,remove;
	
	public MiniGame01MSG(int type) {
		this.type = type;
	}
	
	public int getType() {
		return type;
	}
	
	public void setWinAccept(boolean winAccept) {
		this.winAccept = winAccept;
	}
	public boolean getWinAccept() {
		return this.winAccept;
	}
	
	public Set<Pairs> getAdd() {
		return add;
	}
	public void setAdd(Set<Pairs> add) {
		this.add = add;
	}
	
	public Set<Pairs> getRemove() {
		return remove;
	}
	public void setRemove(Set<Pairs> remove) {
		this.remove = remove;
	}
	
	public static class Pairs implements Serializable {
		public char alpha;
		public int col, row;
		public Pairs(int col, int row, char alpha) {
			this.col = col;
			this.row = row;
			this.alpha = alpha;
		}
		
		@Override
		public boolean equals(Object o) {
			if(o instanceof Pairs) {
				return ((Pairs)o).col == this.col || 
						((Pairs)o).row == this.row || 
						((Pairs)o).alpha == this.alpha;
			} else
				return super.equals(o);
		}
	}
}
