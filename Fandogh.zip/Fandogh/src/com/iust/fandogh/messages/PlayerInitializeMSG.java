package com.iust.fandogh.messages;

import java.io.Serializable;

public class PlayerInitializeMSG implements Serializable {
	public final static int PLAYER_CHANGE = 11;
	public final static int PLAYER_ENTER = 12;
	public final static int PLAYER_EXIT = 13;
}
