package com.iust.fandogh.messages;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class GameMSG implements Serializable{
	public static final int START_GAME = 21;
	public static final int END_GAME = 22;
	public static final int END_GAME_REQUEST = 23;
	
	int type = -1;
	int rounds = -1;
	HashMap<Integer, Integer> modes = null;
	HashMap<String, HashMap<Integer, String>> playerFields;
	ArrayList<Integer> fields;
	int[] dashbordAlphabets;
	int score;
	
	public GameMSG(int type) {
		this.type = type;
	}
	
	public int getType() {
		return type;
	}
	
	public void setScore(int score) {
		this.score = score;
	}
	public int getScore() {
		return score;
	}
	
	public void setRounds(int rounds) {
		this.rounds = rounds;
	}
	public int getRounds() {
		return rounds;
	}
	
	public int[] getDashbordAlphabets() {
		return dashbordAlphabets;
	}
	public void setDashbordAlphabets(int[] dashbordAlphabets) {
		this.dashbordAlphabets = dashbordAlphabets;
	}
	
	public void setModes(HashMap<Integer, Integer> modes) {
		this.modes = modes;
	}
	public HashMap<Integer, Integer> getModes() {
		return modes;
	}
	
	public void setPlayerFields(
			HashMap<String, HashMap<Integer, String>> playerFields) {
		this.playerFields = playerFields;
	}
	public HashMap<String, HashMap<Integer, String>> getPlayerFields() {
		return playerFields;
	}
	
	public void setFields(ArrayList<Integer> fields) {
		this.fields = fields;
	}
	public ArrayList<Integer> getFields() {
		return fields;
	}
}
