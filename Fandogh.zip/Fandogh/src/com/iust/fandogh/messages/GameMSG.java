package com.iust.fandogh.messages;

public class GameMSG {
	public static final int START_GAME = 21;
	public static final int END_GAME = 22;
	public static final int END_GAME_REQUEST = 23;
	public static final int END_GAME_GET_FIELDS = 24;
	public static final int END_GAME_GIVE_FIELDS = 25;
	public static final int ALL_FIELDS_REQUEST = 26;
	public static final int ALL_FIELDS_RESPONSE = 27;
}
