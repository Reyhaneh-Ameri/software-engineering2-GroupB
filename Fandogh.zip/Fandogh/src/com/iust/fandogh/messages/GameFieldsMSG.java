package com.iust.fandogh.messages;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class GameFieldsMSG implements Serializable{
	public static final int END_GAME_GET_FIELDS = 31;
	public static final int END_GAME_GIVE_FIELDS = 32;
	public static final int END_GAME_RESULTS = 33;
	public static final int UNSUPPORTED_WORDS = 34;
	
	int type = -1;
	HashMap<String, HashMap<Integer, String>> playerFields = new HashMap<String, HashMap<Integer,String>>();
	HashMap<String, HashMap<Integer, Integer>> playerFieldsPoints = new HashMap<String, HashMap<Integer,Integer>>();
	int dashbordAlphabets[];
	int buy;
	
	public GameFieldsMSG(int type) {
		this.type = type;
	}
	
	public int getType() {
		return type;
	}
	
	public void addPlayerFields(String name, HashMap<Integer, String> playerFields) {
		this.playerFields.put(name, playerFields);
	}
	public void setPlayerFields(
			HashMap<String, HashMap<Integer, String>> playerFields) {
		this.playerFields = playerFields;
	}
	public HashMap<String, HashMap<Integer, String>> getPlayerFields() {
		return playerFields;
	}
	
	public void addPlayerFieldsPoints(String name, HashMap<Integer, Integer> playerFieldsPoints) {
		this.playerFieldsPoints.put(name, playerFieldsPoints);
	}
	public void setPlayerFieldsPoints(
			HashMap<String, HashMap<Integer, Integer>> playerFieldsPoints) {
		this.playerFieldsPoints = playerFieldsPoints;
	}
	public HashMap<String, HashMap<Integer, Integer>> getPlayerFieldsPoints() {
		return playerFieldsPoints;
	}
	
	public void setDashbordAlphabets(int[] dashbordAlphabets) {
		this.dashbordAlphabets = dashbordAlphabets;
	}
	public int[] getDashbordAlphabets() {
		return dashbordAlphabets;
	}
	
	public void setBuy(int buy) {
		this.buy = buy;
	}
	public int getBuy() {
		return buy;
	}
}
