package com.iust.fandogh.messages;

import java.io.Serializable;
import java.util.ArrayList;

import android.provider.UserDictionary.Words;

public class UnsupportedWordsMSG implements Serializable {
	ArrayList<String> words;
	
	public UnsupportedWordsMSG(ArrayList<String> Words) {
		this.words = Words;
	}
	
	public ArrayList<String> getWords() {
		return words;
	}
}
