package com.iust.fandogh;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import com.iust.fandogh.controllers.ClientNetworkController;
import com.iust.fandogh.controllers.GameController;
import com.iust.fandogh.controllers.GameController.MiniGame01Controller;
import com.iust.fandogh.controllers.ServerNetworkController;
import com.iust.fandogh.messages.GameMSG;
import com.iust.fandogh.messages.MiniGame01MSG;
import com.iust.fandogh.messages.MiniGame01MSG.Pairs;

import static com.iust.fandogh.entity.AlphabetView.*;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableLayout.LayoutParams;
import android.widget.TableRow;
import android.widget.TextView;

public class MiniGameActivity01 extends Activity {
	HashMap<Pairs, ImageView> currentPairs = new HashMap<Pairs, ImageView>();

	public int startId, endId;
	
	TextView wins, choosens;
	TableLayout charsLayout;
	
	ArrayList<TableRow> trs = new ArrayList<TableRow>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_minigame01);
		
		if(ClientNetworkController.cnc != null)
			ClientNetworkController.cnc.setActivity(this);
		else {
			ServerNetworkController.snc.setActivity(this);
		}
		
		charsLayout=(TableLayout) findViewById(R.id.maintablelayout);
		choosens= (TextView)findViewById(R.id.choosenAkphabets);
		wins=(TextView)findViewById(R.id.winAlphabets);
		
		startGame(((MiniGame01MSG)getIntent().getSerializableExtra("init")).getAdd());
	}
	
	public boolean isCorrectPair(Pairs p, int id) {
		if(!currentPairs.keySet().contains(p)) {
			if(startId-id == 1){
				startId=id;
				return true;
			}else if(id-endId==1){
				endId=id;
				return true;
			}
		}
		return false;
	}
	
	public void startGame(Set<Pairs> adds) {
		for(int i=0; i<GameController.MiniGame01Controller.rows; i++){
			TableRow r= new TableRow(this);
			r.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
			trs.add(r);
		}
		
		for (Pairs pair : adds) {
			int id = 0;
			for(int z=0; z<32; z++)
				if(AlphabetChars[z] == pair.alpha)
					id=z;
			
			ImageView im= new ImageView(this);
			im.setPadding(10, 10, 10, 10);
			im.setImageResource(getRandomImageResource());
			im.setOnClickListener(new alphabetListener(pair, id));
			
			trs.get(pair.row).addView(im);
		}
		
		for(int i=0; i<trs.size(); i++)
			charsLayout.addView(trs.get(i));
	}
	
	public class alphabetListener implements OnClickListener {
		Pairs pair;
		int id;
		
		public alphabetListener(Pairs pair, int id) {
			this.pair = pair;
			this.id = id;
		}
		
		@Override
		public void onClick(View arg0) {
			final ImageView me = (ImageView)arg0;
			
			if(currentPairs.isEmpty()){
				startId=id;
				endId=id;
				
				currentPairs.put(pair, me);
				choosens.append(pair.alpha+" ");
				me.setImageResource(AlphabetImages[id]);
			} else if(isCorrectPair(pair, id)) {
				currentPairs.put(pair, me);
				choosens.append(pair.alpha+" ");
				me.setImageResource(AlphabetImages[id]);
				
				if(currentPairs.size() == GameController.MiniGame01Controller.winBoundary) {
					sendAlphabets();
//					wins.append(choosens.getText());
					
					currentPairs = new HashMap<Pairs, ImageView>();
				}
			}else{
				for (Pairs keyPair : currentPairs.keySet())
					currentPairs.get(keyPair).setImageResource(getRandomImageResource());
				currentPairs = new HashMap<Pairs, ImageView>();
				choosens.setText("");
				
				me.setImageResource(AlphabetImages[id]);
				me.postDelayed(new Runnable() {
					@Override
					public void run() {
						me.setImageResource(getRandomImageResource());
					}
				}, 500);
			}
		}
	}
	
	public void sendAlphabets() {
		if(ClientNetworkController.cnc != null) {
			ClientNetworkController.cnc.sendWinAlphabets(currentPairs.keySet());
		} else {
			((MiniGame01Controller)GameController.minigc).winCharacters(0, currentPairs.keySet());
		}
	}
	
	public void getAlphabets(Set<Pairs> remove, boolean winner) {
		Log.d("asd", "resiiiiiiiiidam");
//		for (Pairs keyPair : currentPairs.keySet())
//			currentPairs.get(keyPair).setImageResource(R.drawable.paper2);
		currentPairs = new HashMap<Pairs, ImageView>();
		choosens.setText("");
		
		if(winner) {
			String win = "";
			for (Pairs p : remove)
				win += p.alpha+ " ";
			wins.append(win);
		}
		
		for (Pairs p : remove) {
			((ImageView)trs.get(p.row).getChildAt(p.col)).setImageResource(R.drawable.paper2);
			((ImageView)trs.get(p.row).getChildAt(p.col)).setClickable(false);
		}
		
//		for (Pairs p : add) {
//			int id = 0;
//			for(int z=0; z<32; z++)
//				if(AlphabetChars[z] == p.alpha)
//					id=z;
//			
//			ImageView im= new ImageView(this);
//			im.setImageResource(getRandomImageResource());
//			im.setOnClickListener(new alphabetListener(p, id));
//			
//			trs.get(p.row).addView(im);
//		}
		
//		charsLayout.invalidate();
	}
	
	public void startNextRound(GameMSG msg) {
		Intent intent = new Intent(this, GameActivity.class);
		intent.putExtra("modes", msg.getModes());
		intent.putExtra("rounds", msg.getRounds());
		intent.putExtra("alphabets", msg.getDashbordAlphabets());
		intent.putExtra("score", msg.getScore());
		
		startActivity(intent);
		this.finish();
	}
	
	public int getRandomImageResource() {
		Random haha = new Random();
		switch (haha.nextInt(5)) {
		case 0:
			return(R.drawable.g1);
		case 1:
			return(R.drawable.g2);
		case 2:
			return(R.drawable.g3);
		case 3:
			return(R.drawable.g4);
		case 4:
			return(R.drawable.g5);
		default:
			return(R.drawable.g1);
		}
	}
}
