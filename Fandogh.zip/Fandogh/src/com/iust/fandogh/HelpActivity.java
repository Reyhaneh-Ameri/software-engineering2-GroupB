package com.iust.fandogh;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TextView;

public class HelpActivity extends Activity{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.help);
		
		Typeface tmp =Typeface.createFromAsset(getAssets(), "Font/B Esfehan Bold.TTF");
		((TextView)findViewById(R.id.t1)).setTypeface(tmp);
		((TextView)findViewById(R.id.t1)).setTextSize(30f);
	}
}
