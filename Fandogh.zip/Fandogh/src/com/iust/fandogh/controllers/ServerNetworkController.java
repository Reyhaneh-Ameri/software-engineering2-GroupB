package com.iust.fandogh.controllers;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.http.conn.util.InetAddressUtils;

import android.app.Activity;
import android.util.Log;

import com.iust.fandogh.GameActivity;
import com.iust.fandogh.JoinActivity;
import com.iust.fandogh.MainActivity;
import com.iust.fandogh.MiniGameActivity01;
import com.iust.fandogh.ResultActivity;
import com.iust.fandogh.ServerActivity;
import com.iust.fandogh.controllers.GameController.MiniGame01Controller;
import com.iust.fandogh.entity.Client;
import com.iust.fandogh.messages.*;
import com.iust.fandogh.messages.MiniGame01MSG.Pairs;

/**
 * Controls and contains all network connections of Server
 * @author FERi
 */
public class ServerNetworkController {
	public static ServerNetworkController snc;
	public final static int port = 5001;
	
	HashMap<Integer, Client> clients = new HashMap<Integer, Client>();
	boolean getNetworkConnection = true;
	Activity activity;
	
	/**
	 * Set static variable and start to getting connections
	 * @author FERi
	 */
	public ServerNetworkController() {
		Thread t = new Thread(new GetConnections());
		t.start();
		
		ServerNetworkController.snc = this;
	}
	
	public void setActivity(Activity activity) {
		this.activity = activity;
	}
	
	/**
	 * Runnable for get and establish clients
	 * @author FERi
	 */
	class GetConnections implements Runnable {
		@Override
		public void run() {
			try {
				ServerSocket serverSock = new ServerSocket(port);
				
				Log.d(MainActivity.tag, "Start to listening to port "+Integer.toString(port));
				
				while (true) {
					Socket clientSocket = serverSock.accept();
					if(!getNetworkConnection)
						break;
					OutputStream clientOS = clientSocket.getOutputStream();
					clientOS.flush();
					InputStream clientIS = clientSocket.getInputStream();
					
					Client tmpClient = new Client(clientIS, clientOS, clientSocket);
					int tmpID = GameController.gc.addPlayer();
					clients.put(tmpID, tmpClient);
					Thread t = new Thread(new ClientHandler(tmpID, tmpClient));
					t.start();
					
					Log.d(MainActivity.tag, "New connection!!!");
				}
				
				serverSock.close();
			} catch (Exception ex) {
				Log.d(MainActivity.tag, "What the fucking problem in network listening!!!");
				ex.printStackTrace();
			}
		}
	}
	
	/**
	 * Runnable for handling one clients IOs
	 * @author FERi
	 */
	public class ClientHandler implements Runnable {
		Client client;
		Integer ID;
		
		public ClientHandler(Integer ID, Client client) {
			this.ID = ID;
			this.client = client;
		}
		
		public void run() {
			Object obj;
			try {
				while ((obj = client.getInput().readObject()) != null) {
					parsMSG(obj);
				}
			} catch(Exception ex) {
				ex.printStackTrace();
			}
		}
		
		public void parsMSG(Object msg) {
			if(msg instanceof String) {
				String[] message = ((String)msg).split(":");
				switch (Integer.valueOf(message[0])) {
				case PlayerInitializeMSG.PLAYER_ENTER:
					GameController.gc.getPlayer(this.ID).setNickname(message[1]);
					
					broadcastMSG(Integer.toString(PlayerInitializeMSG.PLAYER_CHANGE)+ 
							":"+ GameController.gc.getPlayersList());
					((ServerActivity)activity).runOnUiThread(new Runnable() {
						@Override
						public void run() {
							((ServerActivity)activity).refreshPlayers(GameController.gc.getPlayersList().split(","));
						}
					});
					break;
				case PlayerInitializeMSG.PLAYER_EXIT:
					Log.d(MainActivity.tag, "chera in umade!?");
					GameController.gc.removePlayer(ID);
					clients.remove(ID);
					 
					broadcastMSG(Integer.toString(PlayerInitializeMSG.PLAYER_CHANGE)+ 
							":"+ GameController.gc.getPlayersList());
					((ServerActivity)activity).runOnUiThread(new Runnable() {
						@Override
						public void run() {
							((ServerActivity)activity).refreshPlayers(GameController.gc.getPlayersList().split(","));
						}
					});
				case 111:
					if(GameController.gc.kamavordan(this.ID)) {
						sendEndRoundRequestMSG();
						GameController.gc.endGame(GameController.gc.getPlayer(0).getNickname(), 
								((GameActivity)activity).getFields());
					}
					break;
				default:
				}
			} else if(msg instanceof GameMSG) {
//				final GameMSG tmpGameMSG = (GameMSG)msg;
				switch (((GameMSG)msg).getType()) {
				case GameMSG.END_GAME_REQUEST:
					sendEndRoundRequestMSG();
					GameController.gc.endGame(GameController.gc.getPlayer(0).getNickname(), 
							((GameActivity)activity).getFields());
					break;
				default:
					Log.d(MainActivity.tag, "Problem in messages!!!");
					break;
				}
			} else if(msg instanceof GameFieldsMSG) {
				final GameFieldsMSG tmpGameFieldsMSG = (GameFieldsMSG)msg;
				switch (((GameFieldsMSG)msg).getType()) {
				case GameFieldsMSG.END_GAME_GIVE_FIELDS:
					for (String name : tmpGameFieldsMSG.getPlayerFields().keySet())
						GameController.gc.endGame(name, tmpGameFieldsMSG.getPlayerFields().get(name));
					GameController.gc.getPlayer(ID).setAllCharsCount(tmpGameFieldsMSG.getDashbordAlphabets());
					GameController.gc.getPlayer(ID).addScore(tmpGameFieldsMSG.getBuy()*(-10));
					
					break;
				default:
					Log.d(MainActivity.tag, "Problem in messages!!!");
					break;
				}
			} else if(msg instanceof UnsupportedWordsMSG) {
				GameController.gc.addUnsupportedWords(((UnsupportedWordsMSG)msg).getWords());
			} else if(msg instanceof MiniGame01MSG) {
				final MiniGame01MSG tmpMiniGame01MSG = (MiniGame01MSG)msg;
				switch (((MiniGame01MSG)msg).getType()) {
				case MiniGame01MSG.GAME_WIN:
					((MiniGame01Controller)GameController.minigc).winCharacters(ID, tmpMiniGame01MSG.getRemove());
					break;
				default:
					Log.d(MainActivity.tag, "Problem in messages!!!");
					break;
				}
			}
		}
	}
	
	/**
	 * Broadcast message to all players
	 * @author FERi
	 * @param msg
	 */
	public void broadcastMSG(Object msg) {
		for (int id : clients.keySet()) {
			try {
				clients.get(id).getOutput().writeObject(msg);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * sends start game msg to clients
	 * @param modes : hashmap of modes to send
	 * @param rounds : number of rounds
	 */
	public void sendStartRoundMSG(HashMap<Integer, Integer> modes, int rounds) {
		GameMSG msg = new GameMSG(GameMSG.START_GAME);
		msg.setModes(modes);
		msg.setRounds(rounds);
		
		for (int id : clients.keySet()) {
			try {
				msg.setDashbordAlphabets(GameController.gc.getPlayer(id).getAllCharsCount());
				msg.setScore(GameController.gc.getPlayer(id).getScore());
				
				clients.get(id).getOutput().writeObject(msg);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * send end round to clients and wait for getting fields from all clients
	 */
	public void sendEndRoundRequestMSG() {
		Log.d(MainActivity.tag, "send get field");
		GameFieldsMSG msg = new GameFieldsMSG(GameFieldsMSG.END_GAME_GET_FIELDS);
		
		broadcastMSG(msg);
	}
	
	/**
	 * send result of fields for going to result page
	 * @param playerFields : player fields
	 * @param scores : scores of each player
	 */
	public void sendEndRoundMSG(HashMap<String, HashMap<Integer, String>> playerFields, 
			HashMap<String, HashMap<Integer, Integer>> scores) {
		GameFieldsMSG msg = new GameFieldsMSG(GameFieldsMSG.END_GAME_RESULTS);
		msg.setPlayerFields(playerFields);
		msg.setPlayerFieldsPoints(scores);
		broadcastMSG(msg);
		
		((GameActivity)ServerNetworkController.snc.activity).endGame(playerFields, scores);
	}
	
	/**
	 * send message for rancking page
	 * @param names : sorted names according to score
	 */
	public void sendFinalPageInfo(HashMap<String, Integer> names) {
		broadcastMSG(names);
	}
	
	/**
	 * send message for getting accept of unsupported words
	 * @param words
	 */
	public void coverUnsupportedWords(ArrayList<String> words) {
		Log.d(MainActivity.tag, "covering unnns"+Integer.toString(words.size()));
		final ArrayList<String> finalWords = words;
		UnsupportedWordsMSG msg = new UnsupportedWordsMSG(words);
		((GameActivity)activity).runOnUiThread(new Runnable() {
			@Override
			public void run() {
				((GameActivity)activity).checkUnsupportedWords(finalWords);
			}
		});
		
		broadcastMSG(msg);
	}
	
	public void sendRefreshMiniGame01(Set<Pairs> remove, int winner) {
		MiniGame01MSG msg = new MiniGame01MSG(MiniGame01MSG.GAME_WIN);
		HashSet<Pairs> tmp = new HashSet<MiniGame01MSG.Pairs>();
		for (Pairs p : remove) {
			tmp.add(p);
		}
//		msg.setAdd(add);
		msg.setRemove(tmp);
		
		((MiniGameActivity01)activity).getAlphabets(tmp, msg.getWinAccept());
		for (int id : clients.keySet()) {
			try {
				if(id == winner)
					msg.setWinAccept(true);
				else
					msg.setWinAccept(false);
				
					clients.get(id).getOutput().writeObject(msg);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void sendStartMiniGame01MSG(Set<Pairs> init) {
		MiniGame01MSG msg = new MiniGame01MSG(MiniGame01MSG.GAME_INITIALIZE);
		msg.setAdd(init);
//		msg.setRemove(remove);
		msg.setWinAccept(false);
		
		broadcastMSG(msg);
		
		((ResultActivity)activity).startNextMiniGame(1, msg);
	}
	
	/**
	 * Function for cancel getting connections
	 * @author FERi
	 */
	public void stopGettingConnection() {
		getNetworkConnection = false;
	}
	
	
	/**
	 * Get IP address of device
	 * @return IP address as string, if device is not connected then return null
	 */
	public static String getIPv4Address() {
		try {
			List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
			for (NetworkInterface intf : interfaces) {
				List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
				for (InetAddress addr : addrs) {
					if (!addr.isLoopbackAddress()) {
						String sAddr = addr.getHostAddress().toUpperCase();
						boolean isIPv4 = InetAddressUtils.isIPv4Address(sAddr); 
						if (isIPv4) 
							return sAddr;
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
	
}
