package com.iust.fandogh.controllers;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import com.iust.fandogh.GameActivity;
import com.iust.fandogh.JoinActivity;
import com.iust.fandogh.MainActivity;
import com.iust.fandogh.MiniGameActivity01;
import com.iust.fandogh.ResultActivity;
import com.iust.fandogh.entity.Player;
import com.iust.fandogh.messages.GameFieldsMSG;
import com.iust.fandogh.messages.GameMSG;
import com.iust.fandogh.messages.MiniGame01MSG;
import com.iust.fandogh.messages.MiniGame01MSG.Pairs;
import com.iust.fandogh.messages.PlayerInitializeMSG;
import com.iust.fandogh.messages.UnsupportedWordsMSG;

import android.R.integer;
import android.R.string;
import android.app.Activity;
import android.provider.ContactsContract.CommonDataKinds.Nickname;
import android.util.Log;

/**
 * class for join to server and creating sockets
 * @author Farhad hosseinkhani,reyhane ameri
 *
 */
public class ClientNetworkController {
	public static ClientNetworkController cnc = null;
	
	Activity activity;
	
	private Socket sock;
	ObjectInputStream ois = null;
	ObjectOutputStream oos = null;

	public String nickname;
		
	public ClientNetworkController(String IP, String nickname) {
		this.nickname = nickname;
		
		Thread join = new Thread(new JoinToNetwork(IP, ServerNetworkController.port));
		join.start();
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					Thread.sleep(3000);
					if(oos==null || ois == null)
						((JoinActivity)activity).finish();
				} catch (Exception e) {
				}
			} 
		}).start();
		
		ClientNetworkController.cnc = this;
	}
	
	public void setActivity(Activity activity) {
		this.activity = activity;
	}
	
	/**
	 * runnable for join to server
	 * @author FERi
	 */
	class JoinToNetwork implements Runnable {
		String IP;
		int Port;
		
		public JoinToNetwork(String IP, int Port) {
			this.IP = IP;
			this.Port = Port;
		}
		
		@Override
		public void run() {
			try {
				Log.d(MainActivity.tag, "Joining to "+IP+":"+Integer.toString(Port));
				
				sock = new Socket(IP,Port);
				oos = new ObjectOutputStream(sock.getOutputStream());
				oos.flush();
				ois = new ObjectInputStream(sock.getInputStream());
				
				Log.d(MainActivity.tag ,"Networking established");
				
				//BIG problem boy!!! Its not thread safe! :X IDK!!!?
				Thread MSGparser = new Thread(new IncommingMessagesParser());
				MSGparser.start();
				
//				Initialize user in server
				Log.d(MainActivity.tag ,"Send Initialize message");
				oos.writeObject(Integer.valueOf(PlayerInitializeMSG.PLAYER_ENTER)+ 
						":"+ nickname);
				Log.d(MainActivity.tag ,"Complete initialization");
			} catch(Exception ex) {
				Log.d(MainActivity.tag , "Problem in connecting to server");
				ex.printStackTrace();
			}
		}
		
		/**
		 * thread for parsing incomming maessages
		 * @author Farhad hosseinkhani,reyhane ameri
		 */
		class IncommingMessagesParser implements Runnable {
			@Override
			public void run() {
				try {
					Object msg;
					while((msg = ois.readObject()) != null) {
						if(msg instanceof String) {
							final String[] message = ((String)msg).split(":");
							switch (Integer.valueOf(message[0])) {
							case PlayerInitializeMSG.PLAYER_CHANGE:
								((JoinActivity)activity).runOnUiThread(new Runnable() {
									@Override
									public void run() {
										((JoinActivity)activity).refreshPlayers(message[1].split(","));
									}
								});
								break;
							default:
								break;
							}
						} else if(msg instanceof GameMSG) {
							final GameMSG tmpGameMSG = (GameMSG)msg;
							switch (((GameMSG)msg).getType()) {
							case GameMSG.START_GAME:
								if(activity instanceof JoinActivity) {
									((JoinActivity)activity).runOnUiThread(new Runnable() {
										@Override
										public void run() {
										((JoinActivity)activity).startGame(tmpGameMSG);
										}
									});
								} else if(activity instanceof ResultActivity) {
									((ResultActivity)activity).runOnUiThread(new Runnable() {
										@Override
										public void run() {
											((ResultActivity)activity).startNextRound(tmpGameMSG);
										}
									});
								} else if(activity instanceof MiniGameActivity01) {
									((MiniGameActivity01)activity).runOnUiThread(new Runnable() {
										@Override
										public void run() {
											((MiniGameActivity01)activity).startNextRound(tmpGameMSG);
										}
									});
								}
								break;
//							case GameMSG.END_GAME_GET_FIELDS:
//								break;
							default:
								Log.d(MainActivity.tag, "Problem in messages!!!");
								break;
							}
						} else if(msg instanceof GameFieldsMSG) {
							final GameFieldsMSG tmpGameFieldsMSG = (GameFieldsMSG)msg;
							switch (((GameFieldsMSG)msg).getType()) {
							case GameFieldsMSG.END_GAME_GET_FIELDS:
								sendFields();
								break;
							case GameFieldsMSG.END_GAME_RESULTS:
								((GameActivity)activity).runOnUiThread(new Runnable() {
									@Override
									public void run() {
										((GameActivity)activity).endGame(tmpGameFieldsMSG.getPlayerFields(), 
												tmpGameFieldsMSG.getPlayerFieldsPoints());
									}
								});
								break;
							default:
								Log.d(MainActivity.tag, "Problem in messages!!!");
								break;
							}
						} else if(msg instanceof UnsupportedWordsMSG) {
							final ArrayList<String> words = ((UnsupportedWordsMSG)msg).getWords();
							((GameActivity)activity).runOnUiThread(new Runnable() {
								@Override
								public void run() {
									((GameActivity)activity).checkUnsupportedWords(words);
								}
							});
						} else if(msg instanceof HashMap<?, ?>) {
							final HashMap<String, Integer> names = (HashMap<String, Integer>)msg;
							((ResultActivity)activity).runOnUiThread(new Runnable() {
								@Override
								public void run() {
									((ResultActivity)activity).finalPage(names);
								}
							});
						} else if(msg instanceof MiniGame01MSG) {
							final MiniGame01MSG tmpMiniGame01MSG = (MiniGame01MSG)msg;
							switch (((MiniGame01MSG)msg).getType()) {
							case MiniGame01MSG.GAME_INITIALIZE:
								((ResultActivity)activity).runOnUiThread(new Runnable() {
									@Override
									public void run() {
										((ResultActivity)activity).startNextMiniGame(1, tmpMiniGame01MSG);
									}
								});
								break;
							case MiniGame01MSG.GAME_WIN:
								((MiniGameActivity01)activity).runOnUiThread(new Runnable() {
									@Override
									public void run() {
										((MiniGameActivity01)activity).getAlphabets(
												tmpMiniGame01MSG.getRemove(), 
												tmpMiniGame01MSG.getWinAccept());
									}
								});
								break;
							case MiniGame01MSG.GAME_FINISHED:
								break;
							default:
								Log.d(MainActivity.tag, "Problem in messages!!!");
								break;
							}
						}
					}
				} catch(Exception ex) {
					ex.printStackTrace();
				}
			}
		}
	}
	
	public void exitGame() {
		try {
			oos.writeObject(Integer.valueOf(PlayerInitializeMSG.PLAYER_EXIT)+ 
					":"+ nickname);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void sendEndGameRequest() {
		Log.d(MainActivity.tag, "send end game request");
		try {
			GameMSG msg = new GameMSG(GameMSG.END_GAME_REQUEST);
			
			oos.writeObject(msg);
		} catch (IOException e) { 
			e.printStackTrace();
		}
	}
	
	public void sendFields() {
		Log.d(MainActivity.tag, "Sending fields.....");		
		try {
			GameFieldsMSG msg = new GameFieldsMSG(GameFieldsMSG.END_GAME_GIVE_FIELDS);
			msg.addPlayerFields(nickname, ((GameActivity)activity).getFields());
			msg.setDashbordAlphabets(((GameActivity)activity).dashbordAlphabets);
			msg.setBuy(((GameActivity)activity).buy);
			
			oos.writeObject(msg);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void sendUnsupportedWordsConfirm(ArrayList<String> words) {
		UnsupportedWordsMSG msg = new UnsupportedWordsMSG(words);
		
		try {
			oos.writeObject(msg);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void sendWinAlphabets(Set<Pairs> wins) {
		MiniGame01MSG msg = new MiniGame01MSG(MiniGame01MSG.GAME_WIN);
		HashSet<Pairs> tmp = new HashSet<MiniGame01MSG.Pairs>();
		for (Pairs p : wins)
			tmp.add(p);
		msg.setRemove(tmp);
		
		try {
			oos.writeObject(msg);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void sendKamavordam() {
		try {
			oos.writeObject("111:"+ nickname);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
