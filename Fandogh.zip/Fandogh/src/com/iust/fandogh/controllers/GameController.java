package com.iust.fandogh.controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

import android.R.id;
import android.util.Log;

import com.iust.fandogh.GameActivity;
import com.iust.fandogh.MainActivity;
import com.iust.fandogh.MiniGameActivity01;
import com.iust.fandogh.MiniGameActivity01.alphabetListener;
import com.iust.fandogh.ResultActivity;
import com.iust.fandogh.entity.AlphabetView;
import com.iust.fandogh.entity.Player;
import com.iust.fandogh.messages.GameMSG;
import com.iust.fandogh.messages.MiniGame01MSG;
import com.iust.fandogh.messages.MiniGame01MSG.Pairs;

/**
 * Controll game and just run on servers
 * @author FERi
 */
public class GameController {
	public static final int MODE_KEYBOARD = 1;
	public static final int MODE_KEYBOARD_1 = 11;
	public static final int MODE_KEYBOARD_2 = 12;
	public static final int MODE_START_CHARACTER = 2;
	public static final int MODE_END_CHARACTER = 3;
	public static final int MODE_ALPHABETS = 4;
	public static final int MODE_ALPHABETS_1 = 41;
	public static final int MODE_ALPHABETS_2 = 42;
	public static final int MODE_FIELDS = 5;
	
	public static final int STATE_INIT = -1;
	public static final int STATE_MAINGAME = 1;
	public static final int STATE_SCORE = 2;
	public static final int STATE_RANKING = 3;
	
	public static GameController gc = null;
	public static Object minigc = null;
	
	int round = 0;
	int state = STATE_INIT;
	ArrayList<Player> players = new ArrayList<Player>();
	HashMap<Integer, Integer> modes = new HashMap<Integer, Integer>();
	HashMap<String, Integer> unsupportedWords = new HashMap<String, Integer>();
	HashMap<String, HashMap<Integer, String>> playerFields = new HashMap<String, HashMap<Integer,String>>();
	
	/**
	 * ceate instance
	 * @param nickname : username of server
	 */
	public GameController(String nickname) {
		int tmpID = this.addPlayer();
		players.get(0).setNickname(nickname);
		
		GameController.gc = this;
	}
	
	/**
	 * return the player instance for further things
	 * @param ID : id of player
	 * @return instance of player
	 */
	public Player getPlayer(int ID) {
		for (Player p : players)
			if(p.getID()==ID)
				return p;
		
		return null;
	}
	
	/**
	 * list player names for join page
	 * @return string of names seperated by ","
	 */
	public String getPlayersList() {
		String ans = "";
		for (Player p : players)
			if(p.getNickname()!=null)
				ans+=p.getNickname()+",";
		return ans;
	}
	
	/**
	 * add player in list
	 * @return id of player
	 */
	public int addPlayer() {
		Player tmpPlayer = new Player();
		players.add(tmpPlayer);
		return tmpPlayer.getID();
	}
	/**
	 * remove player from list
	 * @param ID of player
	 */
	public void removePlayer(int ID) {
		for (Player p : players)
			if(p.getID()==ID)
				players.remove(p);
	}
	
	/**
	 * create new game and start first round
	 * @param modes : hashmap of modes in serverActivity
	 * @param rounds : number of rounds set on server activity
	 */
	public void startGame(HashMap<Integer, Integer> modes, int rounds) {
		this.playerFields = new HashMap<String, HashMap<Integer,String>>();
		
		this.round = rounds;
		this.modes = modes;
		
//		
		
		state = STATE_MAINGAME;
		
		ServerNetworkController.snc.stopGettingConnection();
		ServerNetworkController.snc.sendStartRoundMSG(modes, rounds);
		kams = new ArrayList<Integer>();
	}
	
	/**
	 * for starting next round
	 */
	boolean isMiniGamePlayed = false;
	public HashMap<String, Integer> nextRound() {
		if(round>0) {
			if(modes.get(MODE_ALPHABETS)==MODE_ALPHABETS_1 || isMiniGamePlayed==true) {
				ServerNetworkController.snc.sendStartRoundMSG(modes, round);
				kams = new ArrayList<Integer>();
				isMiniGamePlayed = false;
				return null;
			}
			else {
				isMiniGamePlayed = true;
				
				GameController.minigc = new MiniGame01Controller();
				ServerNetworkController.snc.sendStartMiniGame01MSG(
						((MiniGame01Controller)GameController.minigc).characters);
				new Thread(new Runnable() {
					@Override
					public void run() {
						try {
							Thread.sleep(60000);
							
							ServerNetworkController.snc.sendStartRoundMSG(modes, round);
							final GameMSG msg = new GameMSG(GameMSG.START_GAME);
							msg.setModes(modes);
							msg.setRounds(round);
							msg.setDashbordAlphabets(GameController.gc.getPlayer(0).getAllCharsCount());
							msg.setScore(GameController.gc.getPlayer(0).getScore());
							((MiniGameActivity01)ServerNetworkController.snc.activity).runOnUiThread(new Runnable() {
								@Override
								public void run() {
									((MiniGameActivity01)ServerNetworkController.snc.activity).startNextRound(msg);
								}
							});
							Log.d("as", "asdasdasdasdasdasdasd");
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}).start();
				return new HashMap<String, Integer>();
			}
		} else {
//			Collections.sort(players, new Comparator<Player>() {
//				@Override
//				public int compare(Player arg0, Player arg1) {
//					if(arg0.getScore()>arg1.getScore())
//						return -1;
//					return 1;
//				}
//			});
			
			HashMap<String, Integer> ans = new HashMap<String, Integer>();
			for (Player p : players) {
				ans.put(p.getNickname(), p.getScore());
			}
			ServerNetworkController.snc.sendFinalPageInfo(ans);
			
			return ans;
		}	
	}
		
	public void setModes(HashMap<Integer, Integer> modes) {
		this.modes = modes;
	}
	public HashMap<Integer, Integer> getModes() {
		return modes;
	}
	
	public void setRound(int round) {
		this.round = round;
	}
	public int getRound() {
		return round;
	}
	
//	TODO che khabare =))
	/**
	 * for getting words are not on database
	 */
	int allAnswers = 0;
	public void addUnsupportedWords(ArrayList<String> newWords) {
		if(allAnswers==players.size()) {
			allAnswers = 0;
			unsupportedWords = new HashMap<String, Integer>();
		}
		
		for (String w : newWords) {
			if(unsupportedWords.keySet().contains(w))
				unsupportedWords.put(w, unsupportedWords.get(w)+1);
			else
				unsupportedWords.put(w, 1);
		}
		allAnswers++;
		
		if(allAnswers==players.size()) {
			ArrayList<String> ans = new ArrayList<String>();
			for (String word : unsupportedWords.keySet()) {
				if(unsupportedWords.get(word)> players.size()/2)
					ans.add(word);
			}
			calculateScores(ans);
		}
	}
	
	/**
	 * add player fields in array and at end goes to search unsupported words
	 * @param name : player name
	 * @param fields : fields and words of player 
	 */
	public void endGame(String name, HashMap<Integer, String> fields) {
		playerFields.put(name, fields);
		
		if(playerFields.keySet().size()==players.size()) {
			round--;
			
			NotSupportedWords();
		}
	}
	
	/**
	 * get fields of game for showing in result page
	 * @return all fields in a hashmap
	 */
	public HashMap<String, HashMap<Integer, String>> getPlayerFields() {
		return playerFields;
	}
	
	/**
	 * extract not supported words and send them through server network controller
	 */
	public void NotSupportedWords() {
		ArrayList<String> newWords=new ArrayList<String>();
		if(modes.get(MODE_START_CHARACTER) == -1 && modes.get(MODE_END_CHARACTER) == -1) {
			for (String name : playerFields.keySet())
				for (Integer fieldNum : playerFields.get(name).keySet())
					if (!DatabaseController.dbc.isItThere(fieldNum, playerFields.get(name).get(fieldNum)) &&
							!newWords.contains(playerFields.get(name).get(fieldNum)))
						newWords.add(playerFields.get(name).get(fieldNum));
		} else if(modes.get(MODE_START_CHARACTER) == -1) {
			for (String name : playerFields.keySet())
				for (Integer fieldNum : playerFields.get(name).keySet())
					if (!DatabaseController.dbc.isItThere(fieldNum, playerFields.get(name).get(fieldNum)) &&
							!newWords.contains(playerFields.get(name).get(fieldNum)) && 
							playerFields.get(name).get(fieldNum).
								endsWith(AlphabetView.AlphabetChars[modes.get(MODE_END_CHARACTER)]+""))
						newWords.add(playerFields.get(name).get(fieldNum));
		} else if(modes.get(MODE_END_CHARACTER) == -1) {
			for (String name : playerFields.keySet())
				for (Integer fieldNum : playerFields.get(name).keySet())
					if (!DatabaseController.dbc.isItThere(fieldNum, playerFields.get(name).get(fieldNum)) &&
							!newWords.contains(playerFields.get(name).get(fieldNum)) && 
							playerFields.get(name).get(fieldNum).
								startsWith(AlphabetView.AlphabetChars[modes.get(MODE_START_CHARACTER)]+""))
						newWords.add(playerFields.get(name).get(fieldNum));
		} else {
			for (String name : playerFields.keySet())
				for (Integer fieldNum : playerFields.get(name).keySet())
					if (!DatabaseController.dbc.isItThere(fieldNum, playerFields.get(name).get(fieldNum)) &&
							!newWords.contains(playerFields.get(name).get(fieldNum)) && 
							playerFields.get(name).get(fieldNum).
								startsWith(AlphabetView.AlphabetChars[modes.get(MODE_START_CHARACTER)]+"") &&
								playerFields.get(name).get(fieldNum).
								endsWith(AlphabetView.AlphabetChars[modes.get(MODE_END_CHARACTER)]+""))
						newWords.add(playerFields.get(name).get(fieldNum));
		}
		ServerNetworkController.snc.coverUnsupportedWords(newWords);
	}
	
	/**
	 * examine score of each player
	 * @param helperWords : arraylist of words that are not in db but accepted by users
	 * @return hashmap of names and score of each field
	 */
	public HashMap <String, HashMap<Integer, Integer>> calculateScores(ArrayList<String> helperWords) {
		HashMap<String, HashMap<Integer, Integer>> scores=new HashMap<String, HashMap<Integer,Integer>>();
		
		HashMap<String, Integer> dups = new HashMap<String, Integer>();
		for (String name : playerFields.keySet()) {
			for (Integer fieldNum : playerFields.get(name).keySet()) {
				if(dups.containsKey(playerFields.get(name).get(fieldNum)))
					dups.put(playerFields.get(name).get(fieldNum), 
							dups.get(playerFields.get(name).get(fieldNum))+1);
				else
					dups.put(playerFields.get(name).get(fieldNum), 1);
			}
		}
		
		int tmpScore = 0;
		for (String name : playerFields.keySet()) {
			tmpScore = 0;
			scores.put(name, new HashMap<Integer, Integer>());
			for (Integer fieldNum : playerFields.get(name).keySet()) {
				if(modes.get(MODE_START_CHARACTER) != -1 && 
						!playerFields.get(name).get(fieldNum).
							startsWith(AlphabetView.AlphabetChars[modes.get(MODE_START_CHARACTER)]+""))
					scores.get(name).put(fieldNum, 0);
				else if(modes.get(MODE_END_CHARACTER) != -1 && 
						!playerFields.get(name).get(fieldNum).
						endsWith(AlphabetView.AlphabetChars[modes.get(MODE_END_CHARACTER)]+""))
					scores.get(name).put(fieldNum, 0);
				else if(DatabaseController.dbc.isItThere(fieldNum, playerFields.get(name).get(fieldNum)) || 
						helperWords.contains(playerFields.get(name).get(fieldNum))) {
						if(dups.get(playerFields.get(name).get(fieldNum))>1) {
							tmpScore+=10;
							scores.get(name).put(fieldNum, 10);
						} else {
							tmpScore += 20;
							scores.get(name).put(fieldNum, 20);
						}
					} else
						scores.get(name).put(fieldNum, 0);
			}
			Log.d(MainActivity.tag, "scoreee = "+Integer.toString(tmpScore));
			for (Player p : players)
				if(p.getNickname().equals(name))
					p.addScore(tmpScore);
		}
		
//		send all result
		ServerNetworkController.snc.sendEndRoundMSG(playerFields, scores);
		
		return scores;
	}
	
	ArrayList<Integer> kams;
	public boolean kamavordan(int ID) {
		if(!kams.contains(ID)) {
			kams.add(ID);
			
			if(kams.size()>players.size()/2)
				return true;
		}
		return false;
	}
	
	public class MiniGame01Controller {
		public static final int rows = 11;
		public static final int cols = 6;
		public static final int winBoundary = 2;
		
		public HashSet<Pairs> characters = new HashSet<Pairs>();
		Random rand = new Random();
		
		public MiniGame01Controller() {
			for (int i = 0; i < rows*cols; i++)
				characters.add(new Pairs(i%cols, i/cols, 
						AlphabetView.AlphabetChars[rand.nextInt(32)]));
		}
		
		public void winCharacters(int id, Set<Pairs> removed) {
			for (Pairs pair : removed) {
//				Pairs tmpPairs = new Pairs(pair.col, pair.row, 
//						AlphabetView.AlphabetChars[rand.nextInt(32)]);
				
				characters.remove(pair);
//				characters.add(tmpPairs);
//				ret.add(tmpPairs);
				getPlayer(id).increaseCharCount(pair.alpha);
			}
			ServerNetworkController.snc.sendRefreshMiniGame01(removed, id);
//			return ret;
		}
	}
}
