package com.iust.fandogh.controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;

import android.util.Log;

import com.iust.fandogh.GameActivity;
import com.iust.fandogh.MainActivity;
import com.iust.fandogh.entity.AlphabetView;
import com.iust.fandogh.entity.Player;

public class GameController {
	public static final int MODE_KEYBOARD = 1;
	public static final int MODE_KEYBOARD_1 = 11;
	public static final int MODE_KEYBOARD_2 = 12;
	public static final int MODE_START_CHARACTER = 2;
	public static final int MODE_END_CHARACTER = 3;
	public static final int MODE_ALPHABETS = 4;
	public static final int MODE_ALPHABETS_1 = 41;
	public static final int MODE_ALPHABETS_2 = 42;
	
	public static final int STATE_INIT = -1;
	public static final int STATE_MAINGAME = 1;
	public static final int STATE_SCORE = 2;
	public static final int STATE_RANKING = 3;
	
	public static GameController gc = null;
	
	int round = 0;
	char lastChar;
	char firstChar;
	int state = STATE_INIT;
	ArrayList<Player> players = new ArrayList<Player>();
	HashMap<Integer, Integer> modes = new HashMap<Integer, Integer>();
	HashMap<String, HashMap<Integer, String>> playerFields = new HashMap<String, HashMap<Integer,String>>();
	ArrayList<Integer> fields;
	HashMap<String, Integer> unsupportedWords = new HashMap<String, Integer>();
	
	public GameController(String nickname) {
		int tmpID = this.addPlayer();
		players.get(0).setNickname(nickname);
		
		GameController.gc = this;
	}
	
	public Player getPlayer(int ID) {
		for (Player p : players)
			if(p.getID()==ID)
				return p;
		
		return null;
	}
	
	public String getPlayersList() {
		String ans = "";
		for (Player p : players)
			if(p.getNickname()!=null)
				ans+=p.getNickname()+",";
		return ans;
	}
	
	public int addPlayer() {
		Player tmpPlayer = new Player();
		players.add(tmpPlayer);
		return tmpPlayer.getID();
	}
	public void removePlayer(int ID) {
		for (Player p : players)
			if(p.getID()==ID)
				players.remove(p);
	}
	
	public void startGame(HashMap<Integer, Integer> modes, int rounds) {
		this.playerFields = new HashMap<String, HashMap<Integer,String>>();
		
		this.round = rounds;
		this.modes = modes;
		
//		TODO is this okey?
		firstChar = AlphabetView.AlphabetChars[modes.get(GameController.MODE_START_CHARACTER)];
//		lastChar = AlphabetView.AlphabetChars[modes.get(GameController.MODE_END_CHARACTER)];
//		
		
		state = STATE_MAINGAME;
		
		ServerNetworkController.snc.stopGettingConnection();
		ServerNetworkController.snc.sendStartRoundMSG(modes, rounds);
	}
	
	public void nextRound() {
		ServerNetworkController.snc.sendStartRoundMSG(modes, round);
	}
	
	public ArrayList<String> finalPage() {
		Collections.sort(players, new Comparator<Player>() {
			@Override
			public int compare(Player arg0, Player arg1) {
				if(arg0.getScore()>arg1.getScore())
					return -1;
				return 1;
			}
		});
		
		ArrayList<String> ans = new ArrayList<String>();
		for (Player p : players) {
			ans.add(p.getNickname());
		}
		ServerNetworkController.snc.sendFinalPageInfo(ans);
		
		return ans;
	}
	
	public void setModes(HashMap<Integer, Integer> modes) {
		this.modes = modes;
	}
	public HashMap<Integer, Integer> getModes() {
		return modes;
	}
	
	public void setLastChar(Character lastChar) {
		this.lastChar = lastChar;
	}
	public Character getLastChar() {
		return lastChar;
	}
	
	public void setFirstChar(Character firstChar) {
		this.firstChar = firstChar;
	}
	public Character getFirstChar() {
		return firstChar;
	}
	
	public void setRound(int round) {
		this.round = round;
	}
	public int getRound() {
		return round;
	}
	
	public void setFields(ArrayList<Integer> fields) {
		this.fields = fields;
	}
	public ArrayList<Integer> getFields() {
		return fields;
	}
	
//	TODO che khabare =))
	int allAnswers = 0;
	public void addUnsupportedWords(ArrayList<String> newWords) {
		if(allAnswers==players.size()) {
			allAnswers = 0;
			unsupportedWords = new HashMap<String, Integer>();
		}
		
		for (String w : newWords) {
			if(unsupportedWords.keySet().contains(w))
				unsupportedWords.put(w, unsupportedWords.get(w)+1);
			else
				unsupportedWords.put(w, 1);
		}
		allAnswers++;
		
		if(allAnswers==players.size()) {
			ArrayList<String> ans = new ArrayList<String>();
			for (String word : unsupportedWords.keySet()) {
				if(unsupportedWords.get(word)> players.size()/2)
					ans.add(word);
			}
			calculateScores(ans);
		}
	}
	
	public void endGame(String name, HashMap<Integer, String> fields) {
		playerFields.put(name, fields);
		
		if(playerFields.keySet().size()==players.size()) {
			round--;
			
			NotSupportedWords();
		}
	}
	
	public HashMap<String, HashMap<Integer, String>> getPlayerFields() {
		return playerFields;
	}
	
	public void NotSupportedWords() {
		ArrayList<String> newWords=new ArrayList<String>();
		for (String name : playerFields.keySet())
			for (Integer fieldNum : playerFields.get(name).keySet())
				if (!DatabaseController.dbc.isItThere(fieldNum, playerFields.get(name).get(fieldNum)) &&
						!newWords.contains(playerFields.get(name).get(fieldNum)) && 
						playerFields.get(name).get(fieldNum).startsWith(firstChar+"")) //&& 
//						playerFields.get(name).get(fieldNum).endsWith(lastChar+""))
					newWords.add(playerFields.get(name).get(fieldNum));
		
		ServerNetworkController.snc.coverUnsupportedWords(newWords);
	}
	
	public HashMap <String, HashMap<Integer, Integer>> calculateScores(ArrayList<String> helperWords) {
		HashMap<String, HashMap<Integer, Integer>> scores=new HashMap<String, HashMap<Integer,Integer>>();
		
		HashMap<String, Integer> dups = new HashMap<String, Integer>();
		for (String name : playerFields.keySet()) {
			for (Integer fieldNum : playerFields.get(name).keySet()) {
				if(dups.containsKey(playerFields.get(name).get(fieldNum)))
					dups.put(playerFields.get(name).get(fieldNum), 
							dups.get(playerFields.get(name).get(fieldNum))+1);
				else
					dups.put(playerFields.get(name).get(fieldNum), 1);
			}
		}
		
		int tmpScore = 0;
		for (String name : playerFields.keySet()) {
			tmpScore = 0;
			scores.put(name, new HashMap<Integer, Integer>());
			for (Integer fieldNum : playerFields.get(name).keySet()) {
				if((!playerFields.get(name).get(fieldNum).startsWith(firstChar+""))) //|| 
//						!playerFields.get(name).get(fieldNum).endsWith(lastChar+"")))
					scores.get(name).put(fieldNum, 0);
				else if(DatabaseController.dbc.isItThere(fieldNum, playerFields.get(name).get(fieldNum)) || 
						helperWords.contains(playerFields.get(name).get(fieldNum))) {
						if(dups.get(playerFields.get(name).get(fieldNum))>1) {
							tmpScore+=10;
							scores.get(name).put(fieldNum, 10);
						} else {
							tmpScore += 20;
							scores.get(name).put(fieldNum, 20);
						}
					} else
						scores.get(name).put(fieldNum, 0);
			}
			Log.d(MainActivity.tag, "scoreee = "+Integer.toString(tmpScore));
			for (Player p : players)
				if(p.getNickname().equals(name))
					p.addScore(tmpScore);
		}
		
//		send all result
		ServerNetworkController.snc.sendEndRoundMSG(playerFields, scores);
		
		return scores;
	}
}
