package com.iust.fandogh.dialogs;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebView.FindListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.ToggleButton;
import android.widget.TableLayout.LayoutParams;
import android.widget.TableRow;

import com.iust.fandogh.MainActivity;
import com.iust.fandogh.R;
import com.iust.fandogh.dialogs.JoinDialog.NoticeDialogListener;

public class UnsupportedWordsDialog extends DialogFragment{
	public static UnsupportedWordsDialog newInstance(ArrayList<String> words) {
        UnsupportedWordsDialog frag = new UnsupportedWordsDialog();
        Bundle args = new Bundle();
        args.putSerializable("words", words);
        frag.setArguments(args);
        return frag;
    }

	
	/**
	 * An interface for delivering messages to activity that use from this class
	 * Activity must implements this interface to get contact
	 * @author FERi
	 */
	NoticeDialogListener mListener;
	public interface NoticeDialogListener {
		public void onDialogClick(ArrayList<String> words);
	}
	
	/**
	 * Called when this dialog instance created
	 * Verify that the host activity implements the callback interface
	 * @author FERi
	 */
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (NoticeDialogListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString() + " must implement NoticeDialogListener");
		}
	}
	
    /**
     * Called when dialog shown in screen
     * Set listeners and other f things
     * @author FERi
     */
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		LayoutInflater inflater = getActivity().getLayoutInflater();
		View v = inflater.inflate(R.layout.dialog_unsupportedwords, null);
		final TableLayout form = (TableLayout)v.findViewById(R.id.words);
		final ArrayList<ToggleButton> buttons = new ArrayList<ToggleButton>();
		ArrayList<String> words = (ArrayList<String>)getArguments().getSerializable("words");
		for (String w : words) {
			TableRow row = new TableRow(getActivity());
			LinearLayout.LayoutParams rowParams = new LayoutParams(LayoutParams.FILL_PARENT, 0);
			row.setLayoutParams(rowParams);
			
			TableRow.LayoutParams nameParams;
			TextView wordT = new TextView(getActivity());
			wordT.setText(w);
			wordT.setTextColor(Color.WHITE);
			nameParams = new TableRow.LayoutParams(0, TableRow.LayoutParams.FILL_PARENT, 30f);
			row.addView(wordT, nameParams);
			
			ToggleButton wordB = new ToggleButton(getActivity());
			wordB.setHint(w+"");
			nameParams = new TableRow.LayoutParams(0, TableRow.LayoutParams.FILL_PARENT, 30f);
			buttons.add(wordB);
			row.addView(wordB, nameParams);
			
			form.addView(row);
			
//			TableRow row = new TableRow(getActivity());
//			row.setLayoutParams(new TableRow.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
//			
//			TextView wordText = new TextView(getActivity());
//			wordText.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
//			wordText.setText(w);
//			row.addView(wordText);
//			
//			ToggleButton wordButton = new ToggleButton(getActivity());
//			wordButton.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
//			wordButton.setHint(w);
//			buttons.add(wordButton);
//			row.addView(wordButton);
//			
//			form.addView(row);
		}
		
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setView(v).setTitle("کلمات مبهم");
		builder.setPositiveButton("تمام", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				ArrayList<String> ans = new ArrayList<String>();
				for (ToggleButton b : buttons) {
					if(b.isChecked())
						ans.add(b.getHint()+"");
				}
				mListener.onDialogClick(ans);
			}
		});
		
		return builder.create();
	}
}
