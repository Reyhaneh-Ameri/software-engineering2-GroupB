package com.iust.fandogh;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.http.conn.util.InetAddressUtils;

import com.iust.fandogh.controllers.GameController;
import com.iust.fandogh.controllers.ServerNetworkController;
import com.iust.fandogh.entity.Client;
import com.iust.fandogh.entity.Player;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

public class ServerActivity extends Activity {
	LinearLayout clientsLay;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_server);
		
		clientsLay = (LinearLayout)findViewById(R.id.UsersList);
		
		String nickname = getIntent().getStringExtra(MainActivity.NICKNAME);
		getIntent().removeExtra(MainActivity.NICKNAME);
		TextView nn = new TextView(this);
		nn.setText(nickname);
		nn.setTextColor(Color.RED);
		clientsLay.addView(nn);
		
		String ip = ServerNetworkController.getIPv4Address();
		((TextView)findViewById(R.id.IP)).setTextColor(Color.RED);
		((TextView)findViewById(R.id.IP)).setText(ip);
		
		new GameController(nickname);
		new ServerNetworkController();
		ServerNetworkController.snc.setActivity(this);
    }
    
    /**
     * Start game for all users 
     */
    public void startGame(View arg0) {
    	ArrayList<Integer> modes = new ArrayList<Integer>();
    	if(((ToggleButton)findViewById(R.id.Value1)).isChecked())
    		modes.add(GameController.MODE_KEYBOARD_2);
    	else
    		modes.add(GameController.MODE_KEYBOARD_1);
    	GameController.gc.startGame(modes, 2);
		
		
    	Intent intent = new Intent(this, GameActivity.class);
    	intent.putExtra(Integer.toString(GameController.MODE_KEYBOARD), modes.get(0));
    	
    	startActivity(intent);
		this.finish();
    }
	
	public void refreshPlayers(String[] playersName) {
		clientsLay.removeAllViews();
		for (String name : playersName) {
			TextView nn = new TextView(this);
	    	nn.setText(name);
	    	nn.setTextColor(Color.RED);
	    	clientsLay.addView(nn);
		}
	}
}
