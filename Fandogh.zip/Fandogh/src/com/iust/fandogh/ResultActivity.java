package com.iust.fandogh;

import java.util.ArrayList;
import java.util.HashMap;

import com.iust.fandogh.controllers.ClientNetworkController;
import com.iust.fandogh.controllers.DatabaseController;
import com.iust.fandogh.controllers.GameController;
import com.iust.fandogh.controllers.ServerNetworkController;
import com.iust.fandogh.messages.GameMSG;
import com.iust.fandogh.messages.MiniGame01MSG;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class ResultActivity extends Activity {
	
	/**
	 * insert fields views in page
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_score);
		
		if(ClientNetworkController.cnc != null) {
			ClientNetworkController.cnc.setActivity(this);
		} else {
			ServerNetworkController.snc.setActivity(this);
		}
		
		HashMap<String, HashMap<Integer, String>> fields = 
				(HashMap<String, HashMap<Integer,String>>)getIntent().getSerializableExtra("results");
		HashMap<String, HashMap<Integer, Integer>> points = 
				(HashMap<String, HashMap<Integer,Integer>>)getIntent().getSerializableExtra("scores");
		
		
		
		
		TableLayout table = new TableLayout(this);
		
		boolean isFirst = true;
		TextView cell;
		for (String name : fields.keySet()) {
			if(isFirst) {
				TableRow firstRow = new TableRow(this);
//				
				firstRow.addView(new TextView(this));
//				
				for (Integer field : fields.get(name).keySet()) {
					cell = new TextView(this) {
						@SuppressLint("DrawAllocation")
						@Override
						protected void onDraw(Canvas canvas) {
							super.onDraw(canvas);
							Rect rect = new Rect();
							Paint paint = new Paint();
							paint.setStyle(Paint.Style.STROKE);
							paint.setColor(Color.BLUE);
							paint.setStrokeWidth(2);
							getLocalVisibleRect(rect);
							canvas.drawRect(rect, paint);
						}
					};
					cell.setGravity(Gravity.CENTER);
					cell.setPadding(30, 20, 30, 20);
					cell.setTextColor(Color.BLACK);
					cell.setTextSize(75f);
					cell.setText(DatabaseController.fieldNames[field]);
					firstRow.addView(cell);
				}
//				
				cell = new TextView(this) {
					@SuppressLint("DrawAllocation")
					@Override
					protected void onDraw(Canvas canvas) {
						super.onDraw(canvas);
						Rect rect = new Rect();
						Paint paint = new Paint();
						paint.setStyle(Paint.Style.STROKE);
						paint.setColor(Color.BLUE);
						paint.setStrokeWidth(2);
						getLocalVisibleRect(rect);
						canvas.drawRect(rect, paint);
					}
				};
				cell.setGravity(Gravity.CENTER);
				cell.setPadding(30, 20, 30, 20);
				cell.setText("امتیاز");
				cell.setTextColor(Color.BLACK);
				cell.setTextSize(75f);
				firstRow.addView(cell);
//				
				table.addView(firstRow);
				isFirst = false;
			}
			
			TableRow row = new TableRow(this);
			int score = 0;
//			
			cell = new TextView(this) {
				@SuppressLint("DrawAllocation")
				@Override
				protected void onDraw(Canvas canvas) {
					super.onDraw(canvas);
					Rect rect = new Rect();
					Paint paint = new Paint();
					paint.setStyle(Paint.Style.STROKE);
					paint.setColor(Color.BLUE);
					paint.setStrokeWidth(2);
					getLocalVisibleRect(rect);
					canvas.drawRect(rect, paint);
				}
			};
			cell.setGravity(Gravity.CENTER);
			cell.setPadding(30, 20, 30, 20);
			cell.setTextColor(Color.BLACK);
			cell.setTextSize(75f);
			cell.setText(name);
			
			row.addView(cell);
//			
			for (Integer field : fields.get(name).keySet()) {
				cell = new TextView(this) {
					@SuppressLint("DrawAllocation")
					@Override
					protected void onDraw(Canvas canvas) {
						super.onDraw(canvas);
						Rect rect = new Rect();
						Paint paint = new Paint();
						paint.setStyle(Paint.Style.STROKE);
						paint.setColor(Color.BLUE);
						paint.setStrokeWidth(2);
						getLocalVisibleRect(rect);
						canvas.drawRect(rect, paint);
					}
				};
				cell.setGravity(Gravity.CENTER);
				cell.setPadding(30, 20, 30, 20);
				cell.setTextColor(Color.BLACK);
				cell.setTextSize(75f);
				cell.setText(fields.get(name).get(field));
				if(points.get(name).get(field) == 0)
					cell.setBackgroundColor(Color.RED);
				else
					cell.setBackgroundColor(Color.GREEN);
				score += points.get(name).get(field);
				
				row.addView(cell);
			}
//			
			cell = new TextView(this) {
				@SuppressLint("DrawAllocation")
				@Override
				protected void onDraw(Canvas canvas) {
					super.onDraw(canvas);
					Rect rect = new Rect();
					Paint paint = new Paint();
					paint.setStyle(Paint.Style.STROKE);
					paint.setColor(Color.BLUE);
					paint.setStrokeWidth(2);
					getLocalVisibleRect(rect);
					canvas.drawRect(rect, paint);
				}
			};
			cell.setGravity(Gravity.CENTER);
			cell.setPadding(30, 20, 30, 20);
			cell.setTextColor(Color.BLACK);
			cell.setTextSize(75f);
			cell.setText(Integer.toString(score));
			
			row.addView(cell);
//			
			table.addView(row); 
		}
		((LinearLayout)findViewById(R.id.table)).addView(table);
	}
	
	public void nextRound(View arg0) {
		if(ClientNetworkController.cnc != null) {
//			U cant
		} else {
			Intent intent = null;
			HashMap<String, Integer> har = GameController.gc.nextRound();
			
			if(GameController.gc.getRound()>0) {
				if(har==null) {
					intent = new Intent(this, GameActivity.class);
					intent.putExtra("modes", GameController.gc.getModes());
					intent.putExtra("rounds", GameController.gc.getRound());
					intent.putExtra("alphabets", GameController.gc.getPlayer(0).getAllCharsCount());
					intent.putExtra("score", GameController.gc.getPlayer(0).getScore());
					
					startActivity(intent);
					this.finish();
				}
			} else {
				intent = new Intent(this, FinalActivity.class);
				intent.putExtra("final",har);
				startActivity(intent);
				this.finish();
			}
		}
	}
	
	public void startNextMiniGame(int minigame, Object msg) {
		Log.d(MainActivity.tag, "yess");
		Intent intent = null;
		switch (minigame) {
		case 1:
			intent = new Intent(this, MiniGameActivity01.class);
			intent.putExtra("init", (MiniGame01MSG)msg);
			break;
		default:
			return;
		}
		
		startActivity(intent);
		this.finish();
	}
	
	public void startNextRound(GameMSG msg) {
		Intent intent = new Intent(this, GameActivity.class);
		intent.putExtra("modes", msg.getModes());
		intent.putExtra("rounds", msg.getRounds());
		intent.putExtra("alphabets", msg.getDashbordAlphabets());
		intent.putExtra("score", msg.getScore());
		
		startActivity(intent);
		this.finish();
	}
	
	public void finalPage(HashMap<String, Integer> name) {
		Intent intent = new Intent(this, FinalActivity.class);
		intent.putExtra("final", name);
		
		startActivity(intent);
		this.finish();
	}
}
