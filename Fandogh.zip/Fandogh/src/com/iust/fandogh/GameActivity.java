package com.iust.fandogh;

import java.util.ArrayList;
import java.util.HashMap;

import com.iust.fandogh.controllers.ClientNetworkController;
import com.iust.fandogh.controllers.DatabaseController;
import com.iust.fandogh.controllers.GameController;
import com.iust.fandogh.controllers.ServerNetworkController;
import com.iust.fandogh.dialogs.UnsupportedWordsDialog;
import com.iust.fandogh.entity.AlphabetView;
import com.iust.fandogh.entity.EsmFamilKeyboard;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class GameActivity extends FragmentActivity 
	implements UnsupportedWordsDialog.NoticeDialogListener {
	private static int editTexNum;
	
	TextView textArr[];
	HashMap<Integer, Integer> modes;
	
	public int buy = 0;
	public int dashbordAlphabets[];
	 
	/**
	 * set textviews active for edditing
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_maingame);
		
		if(ClientNetworkController.cnc != null)
			ClientNetworkController.cnc.setActivity(this);
		else {
			ServerNetworkController.snc.setActivity(this);
		}
		
//		GET modes
		modes = (HashMap<Integer, Integer>)getIntent().getSerializableExtra("modes");
//		
		EsmFamilKeyboard k = new EsmFamilKeyboard(this.getApplicationContext(), modes.get(GameController.MODE_KEYBOARD));
		((FrameLayout)findViewById(R.id.keyboardLay)).addView(k);
		k.setActivity(this);
//		
		dashbordAlphabets = (int[])getIntent().getSerializableExtra("alphabets");
		((Spinner)findViewById(R.id.kharidhorof)).setOnItemSelectedListener(new listenerS());
		if(modes.get(GameController.MODE_ALPHABETS) == GameController.MODE_ALPHABETS_1 )
			((Spinner)findViewById(R.id.kharidhorof)).setVisibility(View.INVISIBLE);
//		
		if(modes.get(GameController.MODE_START_CHARACTER)!=-1)
			((TextView)findViewById(R.id.gameStartChar)).setText("حرف شروع: " + 
				AlphabetView.AlphabetChars[modes.get(GameController.MODE_START_CHARACTER)]);
		else
			((TextView)findViewById(R.id.gameStartChar)).setText("حرف شروع: -");
//		
		if(modes.get(GameController.MODE_END_CHARACTER)!=-1)
		((TextView)findViewById(R.id.gameFinishChar)).setText("حرف پایان: " + 
				AlphabetView.AlphabetChars[modes.get(GameController.MODE_END_CHARACTER)]);
		else
			((TextView)findViewById(R.id.gameFinishChar)).setText("حرف پایان: -");
//		
		((TextView)findViewById(R.id.gamePoints)).setText("امتیاز: " + 
				Integer.toString(getIntent().getIntExtra("score", 0)));
//		
		((TextView)findViewById(R.id.gameRound)).setText("دست مانده: " + 
				Integer.toString(getIntent().getIntExtra("rounds", 0)));
//		
		
		//TableLayout table = new TableLayout(this);
	//table.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));
		TableLayout table = ((TableLayout)findViewById(R.id.fields));
		TableRow fname = new TableRow(this);
		
		TableRow ftext = new TableRow(this);
		
		int fields = modes.get(GameController.MODE_FIELDS);
		textArr = new TextView[(int)Math.ceil(Math.log10((double)fields))];
		for (int i = 0; i < textArr.length; i++) {
			TextView cell = new TextView(this) {
				@SuppressLint("DrawAllocation")
				@Override
				protected void onDraw(Canvas canvas) {
					super.onDraw(canvas);
					Rect rect = new Rect();
					Paint paint = new Paint();
					paint.setStyle(Paint.Style.STROKE);
					paint.setColor(Color.BLUE);
					paint.setStrokeWidth(4);
					getLocalVisibleRect(rect);
					canvas.drawRect(rect, paint);
				}
			};
			
			cell.setGravity(Gravity.CENTER);
			
			cell.setPadding(30, 20, 30, 20);
			cell.setText(DatabaseController.fieldNames[fields%10]);
//			int size= #0000FF"
			cell.setTextColor(Color.BLACK);
			cell.setTextSize(75f);
			fname.addView(cell);
//			
			
			textArr[i] = new TextView(this) {
				@SuppressLint("DrawAllocation")
				@Override
				protected void onDraw(Canvas canvas) {
					super.onDraw(canvas);
					Rect rect = new Rect();
					Paint paint = new Paint();
					paint.setStyle(Paint.Style.STROKE);
					paint.setColor(Color.BLUE);
					paint.setStrokeWidth(2);
					getLocalVisibleRect(rect);
					canvas.drawRect(rect, paint);
				}
			};
			textArr[i].setGravity(Gravity.CENTER);
			textArr[i].setTextSize(75f);
			
			textArr[i].setPadding(30, 20, 30, 20);
			final int index = i;
			textArr[i].setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View arg0) {
					editTexNum=index;
				}
			});
			
			ftext.addView(textArr[i]);
//			
			
			fields = fields/10;
		}
		table.addView(fname);
		table.addView(ftext);
//	((LinearLayout)findViewById(R.id.fields)).addView(table);
	}
	
	/**
	 * insert char to active textview
	 * @param character
	 */
	public void insertCharacter(char character)
	{
		if(textArr[editTexNum].getText().length()<15)
			for (int i = 0; i < AlphabetView.AlphabetChars.length; i++)
				if(character == AlphabetView.AlphabetChars[i])
					if(dashbordAlphabets[i]>0) {
						textArr[editTexNum].setText(textArr[editTexNum].getText().toString()+character);
						dashbordAlphabets[i]--;
						return;
					}
	}
	
	public void acceptLost(View arg0) {
		if(ClientNetworkController.cnc != null)
			ClientNetworkController.cnc.sendKamavordam();
		else {
			ServerNetworkController.snc.sendEndRoundRequestMSG();
			GameController.gc.endGame(GameController.gc.getPlayer(0).getNickname(), getFields());
		}
	}
	
	/**
	 * backspace active textview
	 * TODO: harf barnemigarde
	 * @param arg0
	 */
	public void clearText(View arg0) {
		if(textArr[editTexNum].getText().toString().length()>0) {
			char tmpc = textArr[editTexNum].getText().charAt(textArr[editTexNum].getText().length()-1);
			for (int i = 0; i < AlphabetView.AlphabetChars.length; i++)
				if(tmpc == AlphabetView.AlphabetChars[i])
					dashbordAlphabets[i]++;
			textArr[editTexNum].setText(textArr[editTexNum].getText().toString().
				substring(0, textArr[editTexNum].getText().toString().length()-1));
		}
	}
	
	/**
	 * sends end game request
	 * if there is a empty field, does not send
	 */
	public void endGameRequest(View arg0) {
//		checkings
		for (TextView field : textArr)
			if(field.getText().length()==0) 
				return;
		if(modes.get(GameController.MODE_START_CHARACTER)!=-1) {
			for (TextView field : textArr)
				if(field.getText().charAt(0) != 
				AlphabetView.AlphabetChars[modes.get(GameController.MODE_START_CHARACTER)]) {
					field.setText("");
					return;
				}
		}
		if(modes.get(GameController.MODE_END_CHARACTER)!=-1) {
			for (TextView field : textArr)
				if(field.getText().charAt(field.getText().length()-1) != 
					AlphabetView.AlphabetChars[modes.get(GameController.MODE_END_CHARACTER)]) {
					field.setText("");
					return;
				}
		}
		
		if(ClientNetworkController.cnc != null)
			ClientNetworkController.cnc.sendEndGameRequest();
		else {
			ServerNetworkController.snc.sendEndRoundRequestMSG();
			GameController.gc.endGame(GameController.gc.getPlayer(0).getNickname(), getFields());
		}
	} 
	
	/**
	 * get all textviews fields to send to server
	 * @return
	 */
	public HashMap<Integer, String> getFields() {
		HashMap<Integer, String> ans = new HashMap<Integer, String>();
		
		int fields = modes.get(GameController.MODE_FIELDS);
		for (int i = 0; i < textArr.length; i++) {
			ans.put(fields%10, textArr[i].getText()+"");
			fields = fields/10;
		}
		return ans;
	}
	
	/**
	 * change activity and view result activity
	 */
	public void endGame(HashMap<String, HashMap<Integer, String>> playerFields, 
			HashMap<String, HashMap<Integer, Integer>> scores) {
		
		Intent intent = new Intent(this, ResultActivity.class);
		intent.putExtra("results", playerFields);
		intent.putExtra("scores", scores);
		
		startActivity(intent);
		this.finish();
	}
	
	/**
	 * open dialog for new words
	 * @param words : arraylist of words that are not in db
	 */
	public void checkUnsupportedWords(ArrayList<String> words) {
		UnsupportedWordsDialog uwd = UnsupportedWordsDialog.newInstance(words);
		uwd.show(this.getSupportFragmentManager(), "check");
	}
	
	/**
	 * listener for unsupported words dialog
	 */
	@Override
	public void onDialogClick(ArrayList<String> words) {
		if(ClientNetworkController.cnc != null)
			ClientNetworkController.cnc.sendUnsupportedWordsConfirm(words);
		else {
			GameController.gc.addUnsupportedWords(words);
		}
	}
	
	public class listenerS implements OnItemSelectedListener {
		@Override
		public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
			if(arg2!=0) {
				dashbordAlphabets[arg2-1]+=3;
				buy ++;
			}
		}
		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			
		}
	}
}
