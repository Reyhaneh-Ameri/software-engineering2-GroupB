package com.iust.fandogh;

import java.util.ArrayList;
import java.util.HashMap;

import com.iust.fandogh.controllers.ClientNetworkController;
import com.iust.fandogh.controllers.DatabaseController;
import com.iust.fandogh.controllers.GameController;
import com.iust.fandogh.controllers.ServerNetworkController;
import com.iust.fandogh.dialogs.UnsupportedWordsDialog;
import com.iust.fandogh.entity.AlphabetView;
import com.iust.fandogh.entity.EsmFamilKeyboard;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

public class GameActivity extends FragmentActivity 
	implements UnsupportedWordsDialog.NoticeDialogListener {
	private static int editTexNum;
	TextView textArr[];
	
	int boughtAlphabets[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ,0};
	
	int dashbordAlphabets[];
	 
	/**
	 * set textviews active for edditing
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_maingame);
		
		if(ClientNetworkController.cnc != null)
			ClientNetworkController.cnc.setActivity(this);
		else {
			ServerNetworkController.snc.setActivity(this);
		} 
		
//		GET modes
		HashMap<Integer, Integer> modes = (HashMap<Integer, Integer>)getIntent().getSerializableExtra("modes");
//		
		EsmFamilKeyboard k = new EsmFamilKeyboard(this.getApplicationContext(), modes.get(GameController.MODE_KEYBOARD));
		((FrameLayout)findViewById(R.id.keyboardLay)).addView(k);
		k.setActivity(this);
//		
		if(modes.get(GameController.MODE_ALPHABETS) == GameController.MODE_ALPHABETS_1 )
			((Button)findViewById(R.id.kharidhorof)).setEnabled(false);
		else
			dashbordAlphabets = (int[])getIntent().getSerializableExtra("alphabets");
//		
		((TextView)findViewById(R.id.gameStartChar)).setText("حرف شروع: " + 
				AlphabetView.AlphabetChars[modes.get(GameController.MODE_START_CHARACTER)]);
//		
		((TextView)findViewById(R.id.gameFinishChar)).setText("حرف پایان: " );//+ 
//				AlphabetView.AlphabetChars[modes.get(GameController.MODE_END_CHARACTER)]);
//		
		((TextView)findViewById(R.id.gamePoints)).setText("امتیاز: " + 
				Integer.toString(getIntent().getIntExtra("score", 0)));
//		
		((TextView)findViewById(R.id.gameRound)).setText("دست مانده: " + 
				Integer.toString(getIntent().getIntExtra("rounds", 0)));
		
		textArr=new TextView[4];
		textArr[0]=(TextView)findViewById(R.id.gol);
		textArr[1]=(TextView)findViewById(R.id.esm);
		textArr[2]=(TextView)findViewById(R.id.rang);
		textArr[3]=(TextView)findViewById(R.id.mive);
		
		for(int i=0;i<textArr.length;i++)
		{
			final int index=i;
			textArr[i].setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View arg0) {
					editTexNum=index;
				}
			});
		}
	}
	
	/**
	 * insert char to active textview
	 * @param character
	 */
	public void insertCharacter(char character)
	{
		textArr[editTexNum].setText(textArr[editTexNum].getText().toString()+character);
	}
	
	public void acceptLost(View arg0) {
		
	}
	
	public void buyCharacter(View arg0) {
		for (int i = 0; i < boughtAlphabets.length; i++) {
			boughtAlphabets[i] += 1;
		}
	}
	
	/**
	 * backspace active textview
	 * TODO: harf barnemigarde
	 * @param arg0
	 */
	public void clearText(View arg0) {
		if(textArr[editTexNum].getText().toString().length()>0)
			textArr[editTexNum].setText(textArr[editTexNum].getText().toString().
				substring(0, textArr[editTexNum].getText().toString().length()-1));
	}
	
	public void endGameRequest(View arg0) {
		for (TextView field : textArr)
			if(field.getText().length()==0) 
				return;
		
		if(ClientNetworkController.cnc != null)
			ClientNetworkController.cnc.sendEndGameRequest();
		else {
			ServerNetworkController.snc.sendEndRoundRequestMSG();
			GameController.gc.endGame(GameController.gc.getPlayer(0).getNickname(), getFields());
		}
	}
	
	/**
	 * get all textviews fields to send to server
	 * @return
	 */
	public HashMap<Integer, String> getFields() {
		HashMap<Integer, String> ans = new HashMap<Integer, String>();
		
		for (int i = 0; i < textArr.length; i++) {
			switch (i) {
			case 0://gol
				ans.put(DatabaseController.flowerInt, textArr[i].getText()+"");
				break;
			case 1://esm
				ans.put(DatabaseController.fnameInt, textArr[i].getText()+"");
				break;
			case 2://rang
				ans.put(DatabaseController.colorInt, textArr[i].getText()+"");
				break;
			case 3://mive
				ans.put(DatabaseController.fruitInt, textArr[i].getText()+"");
				break;
			default:
				break;
			}
		}
		
		return ans;
	}
	
	/**
	 * change activity and view result activity
	 */
	public void endGame(HashMap<String, HashMap<Integer, String>> playerFields, 
			HashMap<String, HashMap<Integer, Integer>> scores) {
		
		Intent intent = new Intent(this, ResultActivity.class);
		intent.putExtra("results", playerFields);
		intent.putExtra("scores", scores);
		
		startActivity(intent);
		this.finish();
	}
	
	public void checkUnsupportedWords(ArrayList<String> words) {
		UnsupportedWordsDialog uwd = UnsupportedWordsDialog.newInstance(words);
		uwd.show(this.getSupportFragmentManager(), "check");
	}
	
	@Override
	public void onDialogClick(ArrayList<String> words) {
		if(ClientNetworkController.cnc != null)
			ClientNetworkController.cnc.sendUnsupportedWordsConfirm(words);
		else {
			GameController.gc.addUnsupportedWords(words);
		}
	}
}
