package com.iust.modernesmfamil2;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.http.conn.util.InetAddressUtils;

import com.iust.modernesmfamil2.controllers.Client;
import com.iust.modernesmfamil2.controllers.NetworkServerController;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import android.widget.ToggleButton;

/**
 * handler of network events in userinterface
 * @author Farhad hosseinkhani,reyhane ameri
 *
 */
public class ServerActivity extends Activity{
	NetworkServerController NSC;
	LinearLayout clientsLay;
	ArrayList<RelativeLayout> users = new ArrayList<RelativeLayout>();
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_server);
        clientsLay = (LinearLayout)findViewById(R.id.UsersList);
//        
        String nickname = getIntent().getStringExtra(MainActivity.NICKNAME);
		getIntent().removeExtra(MainActivity.NICKNAME);
//		RelativeLayout rl = new RelativeLayout(this);
		TextView nn = new TextView(this);
		nn.setText(nickname);
		
//    	RelativeLayout.LayoutParams lp = 
//    			new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
//    	lp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
//    	lp.addRule(RelativeLayout.CENTER_VERTICAL);
    	
    	//    	ImageView iv = SettingsHandler.avatarImg;
//    	RelativeLayout.LayoutParams lp2 = 
//    			new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
    	
//    	ImageView iv = new ImageView(this);
//    	iv.setImageBitmap(SettingsHandler.avatarImg2);
//    	RelativeLayout.LayoutParams lp2 = 
//    			new RelativeLayout.LayoutParams(
//    					RelativeLayout.LayoutParams.WRAP_CONTENT,
//    					RelativeLayout.LayoutParams.WRAP_CONTENT);
//    	lp2.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
//    	lp2.addRule(RelativeLayout.CENTER_VERTICAL);
    	
//    	rl.addView(nn, lp);
//    	rl.addView(iv, lp2);
//    	clientsLay.addView(rl);
		clientsLay.addView(nn);
//      
        String ip = getIPv4Address();
       	((TextView)findViewById(R.id.IP)).setTextColor(Color.RED);
       	((TextView)findViewById(R.id.IP)).setText(ip);
       	NSC = new NetworkServerController(this, nickname);
    }
    
    /**
     * get ip addres
     * @return ip address as string
     */
    public static String getIPv4Address() {
    	try {
    		List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
    		for (NetworkInterface intf : interfaces) {
    			List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
    			for (InetAddress addr : addrs) {
    				if (!addr.isLoopbackAddress()) {
    					String sAddr = addr.getHostAddress().toUpperCase();
    					boolean isIPv4 = InetAddressUtils.isIPv4Address(sAddr); 
    					if (isIPv4) 
    						return sAddr;
    					}
    				}
    			}
    	} catch (Exception ex) {
    		ex.printStackTrace();
    	}
    	return "";
    }
    
    /**
     * start game for all users
     */
    public void startGame(View arg0) {
    	NSC.stopGettingConnection();
    	NSC.startGame();
    	
		Intent intent = new Intent(this, MainGameActivity.class);
//		intent.putExtra(MainActivity.NICKNAME, ""+nickname.getText());
		startActivity(intent);
		this.finish();

    }
    
    public void importClient(Client c) {
//    	RelativeLayout rl = new RelativeLayout(this);
    	Log.d(MainActivity.tag, "import Client,"+c.getNickname());
    	TextView nn = new TextView(this);
    	nn.setText(c.getNickname());
//    	RelativeLayout.LayoutParams lp = 
//    			new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
//    	lp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
//    	lp.addRule(RelativeLayout.CENTER_VERTICAL);
    	
//    	ImageView iv = new ImageView(this);
//    	iv.setImageBitmap(SettingsHandler.avatarImg);
//    	RelativeLayout.LayoutParams lp2 = 
//    			new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
//    	lp2.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
//    	lp2.addRule(RelativeLayout.CENTER_VERTICAL);
    	
//    	rl.addView(nn, lp);
//    	rl.addView(iv, lp2);
    	
//    	users.add(rl);
//    	clientsLay.addView(rl);
    	clientsLay.addView(nn);
    }
}
