package com.iust.modernesmfamil2;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;

import org.apache.http.conn.util.InetAddressUtils;

import com.iust.modernesmfamil2.controllers.NetworkServerController;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ToggleButton;

public class ServerActivity extends Activity{
	NetworkServerController NSC;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_server);
        
        String ip = getIPv4Address();
        if(ip.equals("")) {
        	((TextView)findViewById(R.id.IP)).setTextColor(Color.RED);
        	((TextView)findViewById(R.id.IP)).setText("در حال حاضر به هیچ شبکه ای متصل نیستید");
        } else {
        	((TextView)findViewById(R.id.IP)).setTextColor(Color.RED);
        	((TextView)findViewById(R.id.IP)).setText(ip);
        	NSC = new NetworkServerController();
        }
    }
    
    public static String getIPv4Address() {
    	try {
    		List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
    		for (NetworkInterface intf : interfaces) {
    			List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
    			for (InetAddress addr : addrs) {
    				if (!addr.isLoopbackAddress()) {
    					String sAddr = addr.getHostAddress().toUpperCase();
    					boolean isIPv4 = InetAddressUtils.isIPv4Address(sAddr); 
    					if (isIPv4) 
    						return sAddr;
    					}
    				}
    			}
    	} catch (Exception ex) {
//    		TODO somthing
    	}
    	return "";
    }
    
    public void startGame(View arg0) {
    	NSC.stopGettingConnection();
    }
}
