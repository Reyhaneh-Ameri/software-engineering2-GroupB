package com.iust.modernesmfamil2;

import java.util.ArrayList;

import com.iust.modernesmfamil2.controllers.Client;
import com.iust.modernesmfamil2.controllers.NetworkClientController;
import com.iust.modernesmfamil2.controllers.NetworkServerController;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * The class for representing join page and show network events in userinterface
 * @author Farhad hosseinkhani,reyhane ameri
 *
 */
public class JoinActivity extends Activity{
	NetworkClientController ncc;
	LinearLayout usersList;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_join);
		usersList = (LinearLayout)findViewById(R.id.UsersList);
		
		ncc = new NetworkClientController(getIntent().getStringExtra(MainActivity.IP), 
				getIntent().getStringExtra(MainActivity.NICKNAME), this);
		getIntent().removeExtra(MainActivity.NICKNAME);
		getIntent().removeExtra(MainActivity.IP);
	}
	
	public void importClients(ArrayList<String> clients) {
		usersList.removeAllViews();
		for (String name : clients) {
			Log.d(MainActivity.tag, "client name:"+name);
			TextView nn = new TextView(this);
	    	nn.setText(name);
	    	
	    	usersList.addView(nn);
		}
	}
	
	public void startGame() {
		Log.d(MainActivity.tag, "start the fucking game");
		Intent intent = new Intent(this, MainGameActivity.class);
//		intent.putExtra(MainActivity.NICKNAME, ""+nickname.getText());
		startActivity(intent);
		this.finish();
	}
}
