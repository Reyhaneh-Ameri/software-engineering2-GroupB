package com.iust.modernesmfamil2;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;

/**
 * A dialog box for getting Server IP
 * @author Farhad hosseinkhani
 */
public class JoinDialog extends DialogFragment {
	// Use this instance of the interface to deliver action events
	NoticeDialogListener mListener;
	/* The activity that creates an instance of this dialog fragment must
     * implement this interface in order to receive event callbacks.
     * Each method passes the DialogFragment in case the host needs to query it. */
	public interface NoticeDialogListener {
        public void onDialogPositiveClick(String ip);
        public void onDialogNegativeClick();
    }
	// Override the Fragment.onAttach() method to instantiate the NoticeDialogListener
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        // Verify that the host activity implements the callback interface
        try {
            // Instantiate the NoticeDialogListener so we can send events to the host
            mListener = (NoticeDialogListener) activity;
        } catch (ClassCastException e) {
            // The activity doesn't implement the interface, throw exception
            throw new ClassCastException(activity.toString() + " must implement NoticeDialogListener");
        }
    }
	
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		LayoutInflater inflater = getActivity().getLayoutInflater();
		View v = inflater.inflate(R.layout.dialog_join, null);
		final EditText ip = (EditText)v.findViewById(R.id.ip);
		
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setView(v).setTitle("آدرس سرور بازی");
		builder.setPositiveButton("ملحق شدن", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				try {
					mListener.onDialogPositiveClick(ip.getText().toString());
				} catch(Exception ex) {
					mListener.onDialogPositiveClick("");
				}
			}
		}).setNegativeButton("منصرف شدن", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				Log.d(MainActivity.tag , "negative button pressd");
				mListener.onDialogNegativeClick();
				JoinDialog.this.getDialog().cancel();
			}
		});
		
		return builder.create();
	}
}
 