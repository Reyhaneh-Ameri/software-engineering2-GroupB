package com.iust.modernesmfamil2.controllers;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class GameInitializeMSG implements Serializable{
	public final static short CLIENT_UPDATE = 1;
	public final static short MODE_UPDATE = 2;
	public final static short GAME_STARTED = 3;
	public final static short SERVER_DISCONNECTED = 1;
	
	short MSGtype;
	ArrayList<String> clients;
	HashMap<Integer, Integer> modes;
	ArrayList<String> fields;
	
	public GameInitializeMSG(short MSGtype, ArrayList<String> clients, 
			HashMap<Integer, Integer> modes, ArrayList<String> fields) {
		this.MSGtype = MSGtype;
		this.clients = clients;
		this.fields = fields;
		this.modes = modes;
	}
	
	public short getType() {
		return MSGtype;
	}
	public ArrayList<String> getClients() {
		return clients;
	}
	public Integer getMode(Integer mode) {
		return modes.get(mode);
	}
	public ArrayList<String> getFields() {
		return fields;
	}
}
