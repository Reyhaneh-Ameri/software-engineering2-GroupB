package com.iust.modernesmfamil2.controllers;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import com.iust.modernesmfamil2.MainActivity;

import android.util.Log;

import static com.iust.modernesmfamil2.controllers.GameMSG.*;

/**
 * Class for server network managing.
 */
public class NetworkServerController {
	private final static int port = 5000;
	ArrayList<Client> clients = new ArrayList<Client>();;
	boolean getNetworkConnection = true;
	
	public NetworkServerController() {
		Thread t = new Thread(new GetConnections());
		t.start();
	}
	
	public class ClientHandler implements Runnable {
		Client client;
		
		public ClientHandler(Client client) {
			this.client = client;
		}
		
		public void run() {
			Object obj;
			try {
				while ((obj = client.getInput().readObject()) != null) {
					if(obj instanceof InitializeMSG)
						client.initializeClient((InitializeMSG)obj);
					else if(obj instanceof GameMSG)
						switch (((GameMSG)obj).getType()) {
						case SOME_TYPE:
							System.out.println("haha");
							break;
						default:
							break;
						}
				}
			} catch(Exception ex) {
				ex.printStackTrace();
			}
		}
		
//		public void tellEveryone(Object obj) {
//			if(obj instanceof String) {
//				if(((String)obj).equals("exit"))
//					System.out.println("Client "+(String)obj+" is ofline now!");
//					for(int i=0;i<clients.size();i++) {
//						if(clients.get(i).getName().equals(client.getName())) {
//							clients.remove(i);
//							break;
//						}
//					}
//					
//			} else
//				if(obj instanceof msgObject) {
//					System.out.println("recive msgObject: "+((msgObject)obj).toString());
//				}
//			
//			Iterator<Client> it = clients.iterator();
//			while(it.hasNext()) {
//				try {
//					Client client = it.next(); 
//					ObjectOutputStream writer = client.getObjectOutputStream();
//					writer.writeObject(obj);
//				} catch (Exception ex) {
//					ex.printStackTrace();
//				}
//			}
//		}
	}
	
	public void stopGettingConnection() {
		new Thread(new Runnable() {
			@Override
			public void run() {
				NetworkServerController.this.getNetworkConnection = false;
				Log.d(MainActivity.tag, "stat kon lanati");
			}
		}).start();
	}
	
	class GetConnections implements Runnable {
		@Override
		public void run() {
			try {
				ServerSocket serverSock = new ServerSocket(port);
				while (getNetworkConnection) {
					Socket clientSocket = serverSock.accept();
					
					Client tmpClient = new Client(clientSocket.getInputStream(), 
							clientSocket.getOutputStream(), clientSocket);
					clients.add(tmpClient);
					Thread t = new Thread(new ClientHandler(tmpClient));
					t.start();
					Log.d(MainActivity.tag, "New connection!!!");
				}
				
				serverSock.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}
}
