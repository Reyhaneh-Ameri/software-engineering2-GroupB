package com.iust.modernesmfamil2.controllers;

import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import com.iust.modernesmfamil2.MainActivity;
import com.iust.modernesmfamil2.ServerActivity;

import android.provider.ContactsContract.CommonDataKinds.Nickname;
import android.util.Log;

/**
 * Class for server network managing.
 * @author Farhad hosseinkhani,reyhane ameri
 */
public class NetworkServerController {
	private final static int port = 5000;
	ArrayList<Client> clients = new ArrayList<Client>();
	HashMap<Integer, Integer> modes = new HashMap<Integer, Integer>();
	boolean getNetworkConnection = true;
	ServerActivity sa;
	String nickname;
	
	/**
	 * start to getting coonections in new thread
	 */
	public NetworkServerController(ServerActivity sa, String nickname) {
		Log.d(MainActivity.tag, "nsc construct");
		this.sa = sa;
		this.nickname = nickname;
		
		Thread t = new Thread(new GetConnections());
		t.start();
	}
	
	/**
	 * runnable for getting connections
	 * @author Farhad hosseinkhani,reyhane ameri
	 */
	public class ClientHandler implements Runnable {
		Client client;
		
		public ClientHandler(Client client) {
			this.client = client;
			Log.d(MainActivity.tag, "Client handler start to work");
		}
		
		public void run() {
			Object obj;
			try {
				while ((obj = client.getInput().readObject()) != null) {
					Log.d(MainActivity.tag, "Recive a MSG");
//					For testing
					if(obj instanceof String)
						Log.d(MainActivity.tag, "Recive a MSG from SO: "+(String)obj);
//					
					else
						parsMSG(obj);
				}
			} catch(Exception ex) {
				ex.printStackTrace();
			}
		}
		
		public void parsMSG(Object msg) {
			if(msg instanceof ClientInitializeMSG) {
				client.initializeClient((ClientInitializeMSG)msg);
				broadcastMSG(new GameInitializeMSG(GameInitializeMSG.CLIENT_UPDATE, 
						getClientsNames(), null, null));
				sa.runOnUiThread(new Runnable() {
					@Override
					public void run() {
						sa.importClient(client);
					}
				});
			} else if(msg instanceof GameInitializeMSG) {
				System.out.println(((GameInitializeMSG)msg).getType());
			} else if(msg instanceof GameMSG) {
				System.out.println("game msg recieved");
			}
		}
	}
	
	public void broadcastMSG(Object msg) {
		Iterator<Client> it = clients.iterator();
		while(it.hasNext()) {
			try {
				Client client = it.next(); 
				ObjectOutputStream writer = client.getOutput();
				writer.writeObject(msg);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}
	
	public ArrayList<String> getClientsNames() {
		ArrayList<String> ans = new ArrayList<String>();
		for (Client c : clients)
			if(c.getNickname()!=null)
				ans.add(c.getNickname());
		ans.add(nickname);
		
		return ans;
	}
	
	public void startGame() {
		Iterator<Client> it = clients.iterator();
		while(it.hasNext()) {
			try {
				Client client = it.next(); 
				ObjectOutputStream writer = client.getOutput();
				writer.writeObject(new GameInitializeMSG(GameInitializeMSG.GAME_STARTED, getClientsNames(), modes, null));
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}
	
	/**
	 * function for cancel getting connections
	 */
	public void stopGettingConnection() {
//		new Thread(new Runnable() {
//			@Override
//			public void run() {
				NetworkServerController.this.getNetworkConnection = false;
				Log.d(MainActivity.tag, "stoped listening for clients!!!");
//			}
//		}).start();
	}
	
	/**
	 * runabble for handle joined clients
	 * @author Farhad hosseinkhani,reyhane ameri
	 */
	class GetConnections implements Runnable {
		@Override
		public void run() {
			try {
				ServerSocket serverSock = new ServerSocket(port);
				
				Log.d(MainActivity.tag, "Start to listening to port "+Integer.toString(port));
				
				while (getNetworkConnection) {
					Socket clientSocket = serverSock.accept();
					OutputStream clientOS = clientSocket.getOutputStream();
					clientOS.flush();
					InputStream clientIS = clientSocket.getInputStream();
					
					Client tmpClient = new Client(clientIS, clientOS, clientSocket);
					clients.add(tmpClient);
					Thread t = new Thread(new ClientHandler(tmpClient));
					t.start();
					
					Log.d(MainActivity.tag, "New connection!!!");
				}
				
				serverSock.close();
			} catch (Exception ex) {
				Log.d(MainActivity.tag, "What the fucking problem in network listening!!!");
				ex.printStackTrace();
			}
		}
	}
}
