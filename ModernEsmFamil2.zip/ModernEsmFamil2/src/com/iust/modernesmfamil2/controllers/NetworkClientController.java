package com.iust.modernesmfamil2.controllers;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import com.iust.modernesmfamil2.JoinActivity;
import com.iust.modernesmfamil2.MainActivity;
import com.iust.modernesmfamil2.Settings;
import com.iust.modernesmfamil2.SettingsHandler;

import android.graphics.drawable.BitmapDrawable;
import android.util.Log;

/**
 * class for join to server and creating sockets
 * @author Farhad hosseinkhani,reyhane ameri
 *
 */
public class NetworkClientController {
	JoinActivity ja;
	String nickname;
	
	private Socket sock;
	ObjectInputStream ois;
	ObjectOutputStream oos;
	
	public NetworkClientController(String IP, String nickname, JoinActivity ja) {
		this.ja = ja;
		this.nickname = nickname;
		
		Thread join = new Thread(new JoinToNetwork(IP, 5000));
		join.start();
	}
	
	/**
	 * runnable for join to server
	 * @author FERi
	 *
	 */
	class JoinToNetwork implements Runnable {
		String IP;
		int Port;
		
		public JoinToNetwork(String IP, int Port) {
			this.IP = IP;
			this.Port = Port;
		}
		@Override
		public void run() {
			try {
				Log.d(MainActivity.tag, "Joining to "+IP+":"+Integer.toString(Port));
				
				sock = new Socket(IP,Port);
				oos = new ObjectOutputStream(sock.getOutputStream());
				oos.flush();
				ois = new ObjectInputStream(sock.getInputStream());
				
				Log.d(MainActivity.tag ,"Networking established");
				
				//BIG problem boy!!! Its not thread safe! :X IDK!!!?
				Thread MSGparser = new Thread(new IncommingMessagesParser());
				MSGparser.start();
				
				Log.d(MainActivity.tag ,"Send Initialize message");
				oos.writeObject(new ClientInitializeMSG(SettingsHandler.avatarImg2, nickname));
				Log.d(MainActivity.tag ,"Complete initialization");
			} catch(Exception ex) {
				Log.d(MainActivity.tag , "Problem in connecting to server");
				ex.printStackTrace();
			}
		}
	}
	
	/**
	 * thread for parsing incomming maessages
	 * @author Farhad hosseinkhani,reyhane ameri
	 *
	 */
	class IncommingMessagesParser implements Runnable {
		@Override
		public void run() {
			try {
				Object msg;
				while((msg = ois.readObject()) != null) {
					if(msg instanceof GameInitializeMSG) {
						final GameInitializeMSG finalMSG = (GameInitializeMSG)msg;
						switch (((GameInitializeMSG)msg).getType()) {
						case GameInitializeMSG.CLIENT_UPDATE:
							ja.runOnUiThread(new Runnable() {
								@Override
								public void run() {
									ja.importClients((finalMSG).getClients());
								}
							});
							break;
						case GameInitializeMSG.GAME_STARTED:
							ja.runOnUiThread(new Runnable() {
								@Override
								public void run() {
									ja.startGame();
								}
							});
							break;
						default:
							break;
						}
					}
				}
			} catch(Exception ex) {
				ex.printStackTrace();
			}
		}
	}
}
