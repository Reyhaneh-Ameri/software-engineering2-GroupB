package com.iust.modernesmfamil2.controllers;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import android.util.Log;

public class NetworkClientController {
	private Socket sock;
	ObjectInputStream ois;
	ObjectOutputStream oos;
	
	public NetworkClientController(String IP, int Port) {
		Thread join = new Thread(new JoinToNetwork(IP, Port));
		join.start();
	}
	
	class JoinToNetwork implements Runnable {
		String IP;
		int Port;
		
		public JoinToNetwork(String IP, int Port) {
			this.IP = IP;
			this.Port = Port;
		}
		@Override
		public void run() {
			try {
				sock = new Socket(IP,Port);
				ois = new ObjectInputStream(sock.getInputStream());
				oos = new ObjectOutputStream(sock.getOutputStream());
				Log.d("felan ashghal" ,"networking established");
				
				//BIG problem boy!!! Its not thread safe! :X IDK!!!?
				Thread oisParser = new Thread(new IncommingMessagesParser());
				oisParser.start();
			} catch(Exception ex) {
				ex.printStackTrace();
				
				Log.d("unknown" , "problem in connect to server");
			}

			
		}
	}
	
	class IncommingMessagesParser implements Runnable {
		@Override
		public void run() {
			try {
				Object obj;
				while((obj = ois.readObject()) != null) {
//					runOnUiThread(new Runnable() {
//						@Override
//						public void run() {
//							in.append(lanat + "\n");
//						}
//					});
				}
			} catch(Exception ex) {
				ex.printStackTrace();
			}
		}
	}
}
