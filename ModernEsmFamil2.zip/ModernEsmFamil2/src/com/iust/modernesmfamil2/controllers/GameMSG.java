package com.iust.modernesmfamil2.controllers;

import java.io.Serializable;

public class GameMSG implements Serializable{
	public GameMSG() {
	}
}
