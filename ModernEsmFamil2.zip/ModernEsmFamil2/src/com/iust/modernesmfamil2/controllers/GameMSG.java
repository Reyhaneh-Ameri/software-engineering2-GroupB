package com.iust.modernesmfamil2.controllers;

public class GameMSG {
	public final static int SOME_TYPE= 1;
	
	int type;
	
	public GameMSG() {
	}
	
	public int getType() {
		return type;
	}
}
