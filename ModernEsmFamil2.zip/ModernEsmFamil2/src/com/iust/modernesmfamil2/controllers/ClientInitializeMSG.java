package com.iust.modernesmfamil2.controllers;

import java.io.Serializable;

import android.graphics.Bitmap;
import android.widget.ImageView;


public class ClientInitializeMSG implements Serializable{
//	Bitmap avatar;
	String nickName;
	
	public ClientInitializeMSG(Bitmap avatar, String nickname) {
//		this.avatar = avatar;
		this.nickName = nickname;
	}
	
//	public Bitmap getAvatar() {
//		return avatar;
//	}
	public String getNickname() {
		return nickName;
	}
}
