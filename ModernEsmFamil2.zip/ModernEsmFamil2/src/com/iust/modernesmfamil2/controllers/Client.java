package com.iust.modernesmfamil2.controllers;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;

import android.util.Log;

public class Client {
	public final static int NOT_INITIALIZED = -1;
	
	int ID = NOT_INITIALIZED;
	ObjectOutputStream oos;
	ObjectInputStream ois;
	Socket socket;
	
	public Client(InputStream ois, OutputStream oos, Socket socket) {
		this.socket = socket;
		try {
			this.ois = new ObjectInputStream(ois);
			this.oos = new ObjectOutputStream(oos);
		} catch (IOException e) {
			e.printStackTrace();
			Log.e("no tag yet", "nashod besazam oos o ba ois");
		}
	}
	
	public ObjectInputStream getInput() {
		return ois;
	}
	public ObjectOutputStream getOutput() {
		return oos;
	}
	
	public void initializeClient(InitializeMSG msg) {
		
	}
	
	public int getID() {
		return ID;
	}
}
