package com.iust.modernesmfamil2.controllers;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;

import com.iust.modernesmfamil2.MainActivity;

import android.graphics.Bitmap;
import android.util.Log;

/**
 * Represent clients in network
 * @author Farhad hsoseinkhani
 *
 */
public class Client {
	public static int IdCounter = 1;
	public final static int NOT_INITIALIZED = -1;
	
	int ID = NOT_INITIALIZED;
	String nickname;
//	Bitmap avatar;
	ObjectOutputStream oos;
	ObjectInputStream ois;
	Socket socket;
	
	/**
	 * get input and output stremas of socket
	 * @param ois
	 * @param oos
	 * @param socket
	 */
	public Client(InputStream ois, OutputStream oos, Socket socket) {
		this.socket = socket;
		try {
			this.ois = new ObjectInputStream(ois);
			this.oos = new ObjectOutputStream(oos);
		} catch (IOException e) {
			e.printStackTrace();
			Log.e("no tag yet", "nashod besazam oos o ba ois");
		}
	}
	
	public ObjectInputStream getInput() {
		return ois;
	}
	public ObjectOutputStream getOutput() {
		return oos;
	}
	
	public void initializeClient(ClientInitializeMSG msg) {
		Log.d(MainActivity.tag, "initliaze");
		this.ID = IdCounter;
		IdCounter++;
		this.nickname = msg.getNickname();
//		this.avatar = msg.getAvatar();
	}
	
	public int getID() {
		return ID;
	}
	public String getNickname() {
		return nickname;
	}
//	public Bitmap getAvatar() {
//		return avatar;
//	}
}
