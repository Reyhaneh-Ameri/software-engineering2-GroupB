package com.iust.modernesmfamil2.controllers;

import android.graphics.Bitmap;

public class InitializeMSG {
	Bitmap avatar;
	String nickName;
	
}
