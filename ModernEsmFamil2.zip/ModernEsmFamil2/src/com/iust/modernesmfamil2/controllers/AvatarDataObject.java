package com.iust.modernesmfamil2.controllers;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class AvatarDataObject implements Serializable {
	
	
//	private int sourceWidth, currentWidth;
//	private int sourceHeight, currentHeight;
//	private Bitmap sourceImage;
//	private Canvas sourceCanvas;        
//	private Bitmap currentImage;
//	private Canvas currentCanvas;   
//	private Paint currentPaint; 
//
//	public class BitmapDataObject implements Serializable {
//		public byte[] imageByteArray;
//	}
//	
//	public Bitmap writeBitmapObject(ObjectOutputStream out){
//		try {
//			out.writeInt(currentWidth);
//			out.writeInt(currentHeight);
//			
//			ByteArrayOutputStream stream = new ByteArrayOutputStream();
//			currentImage.compress(Bitmap.CompressFormat.PNG, 100, stream);
//			BitmapDataObject bitmapDataObject = new BitmapDataObject();
//			bitmapDataObject.imageByteArray = stream.toByteArray();
//			
//			out.writeObject(bitmapDataObject);
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
//	
//	/** Included for serialization - read this object from the supplied input stream. */
//	private Bitmap readObject(ObjectInputStream in) {
//		try {
//			sourceWidth = currentWidth = in.readInt();
//			sourceHeight = currentHeight = in.readInt();
//			
//			BitmapDataObject bitmapDataObject = (BitmapDataObject)in.readObject();
//			Bitmap image = BitmapFactory.decodeByteArray(bitmapDataObject.imageByteArray, 0,
//					bitmapDataObject.imageByteArray.length);
//			
//			sourceImage = Bitmap.createBitmap(sourceWidth, sourceHeight, Bitmap.Config.ARGB_8888);
//			currentImage = Bitmap.createBitmap(sourceWidth, sourceHeight, Bitmap.Config.ARGB_8888);
//			
////			sourceCanvas = new Canvas(sourceImage);
////			currentCanvas = new Canvas(currentImage);
////			
////			currentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
////			thumbnailPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
////			thumbnailPaint.setARGB(255, 200, 200, 200);
////			thumbnailPaint.setStyle(Paint.Style.FILL);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
}
