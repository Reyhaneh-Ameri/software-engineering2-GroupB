package com.iust.modernesmfamil2;

public class FileHandler {
	
	public static void writeSettingsFile(int sou,int vib, int mus){
		
	}	
	public static int readSettingsFileSound(){
		return 0;
	}
	public static int readSettingsFileMusic(){
		return 0;
	}
	public static int readSettingsFileVibra(){
		return 0;
	}
}
