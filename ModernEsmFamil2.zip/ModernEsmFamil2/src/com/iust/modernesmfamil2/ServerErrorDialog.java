package com.iust.modernesmfamil2;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;

/**
 * dialog box for reporting errors
 * @author FERi
 */
public class ServerErrorDialog extends DialogFragment {
	// Comments are in ServerDialog
	NoticeDialogListener mListener;
	public interface NoticeDialogListener {
		public void onErrorDialogClick();
	}
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
	    try {
	        mListener = (NoticeDialogListener) activity;
	    } catch (ClassCastException e) {
	        throw new ClassCastException(activity.toString() + " must implement NoticeDialogListener");
	    }
	}
	
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setTitle("Error!").setMessage("در حال حاضر به هیچ شبکه ای متصل نیستید")
		.setNeutralButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				mListener.onErrorDialogClick();
			}
		});
		
		return builder.create();
	}
}